import os
import uuid
import numpy as np
import aiohttp
import asyncio
import hashlib
import base64
import cryptography.x509
import cryptography.hazmat.primitives.asymmetric.rsa
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.backends import default_backend
import config

# region Waiver Generating and signing

fn_cert_pub = os.path.join(os.path.dirname(__file__), '..', 'config', 'server-cert.pem')
fn_cert_key = os.path.join(os.path.dirname(__file__), '..', 'config', 'server-key.pem')

if not os.path.exists(fn_cert_pub):
    fn_cert_pub = os.path.join(os.path.dirname(__file__), 'config', 'server-cert.pem')
if not os.path.exists(fn_cert_key):
    fn_cert_key = os.path.join(os.path.dirname(__file__), 'config', 'server-key.pem')

cert_key: cryptography.hazmat.primitives.asymmetric.rsa.RSAPrivateKeyWithSerialization | None = None
_str_pubkey: str | None = None
_srv_cert: str | None = None


def digitally_sign(message: str) -> str:
    """Sign a string message with a private key"""
    global cert_key
    ''' load private key from file if needed '''
    if cert_key is None:
        with open(fn_cert_key, 'rb') as f:
            cert_key = serialization.load_pem_private_key(f.read(), password=config.ssl_password(),
                                                          backend=default_backend())
    message = message.rstrip('\n ')
    message += '\n\n'
    prehashed = hashlib.sha256(message.encode(encoding="utf-8")).hexdigest()
    sig = cert_key.sign(
        bytes(prehashed, 'utf-8'),
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=32),
        hashes.SHA256())
    ''' pretty format signature for appending to message '''
    sig = base64.b64encode(sig).decode('utf-8')
    chunks = []
    for i in range(0, len(sig), 64):
        chunks.append(sig[i:i + 64])
    signature = f'# SIG # Begin signature block\n'
    for x in chunks:
        signature += f'# {x}\n'
    signature += '# SIG # End signature block'
    ''' return message with attached signature '''
    return message + signature


def verify_digitally_signature(message: str) -> bool:
    """Verify signature using a public key ( not done during encoding )"""
    # load public key from file if needed
    with open(fn_cert_pub, 'rb') as f:
        pub_key = cryptography.x509.load_pem_x509_certificate(f.read(), backend=default_backend()).public_key()
    ''' rebuild signature bytes from text block at end of message '''
    sig_start = message.find('# SIG # Begin signature block\n')
    sigblock = message[sig_start + 30:message.find('# SIG # End signature block')]
    sig = ''
    for chunk in sigblock.split('\n'):
        sig += chunk[2:]
    sig = base64.b64decode(sig)
    ''' rebuild original message without signature '''
    msg = message[:sig_start]
    prehashed = hashlib.sha256(msg.encode(encoding="utf-8")).hexdigest()
    try:
        pub_key.verify(
            sig,
            bytes(prehashed, 'utf-8'),
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=32),
            hashes.SHA256())
        return True  # Valid Signature
    except InvalidSignature:
        return False  # Invalid Signature


def generate_waiver(im: np.ndarray) -> tuple[uuid.UUID, str]:
    global _str_pubkey
    template = """
  ---------------------------------------------------------------------------
  I hereby waive all copyright and related or neighboring rights together
  with all associated claims and causes of action with respect to this work
  to the extent possible under the law.
  I have read and understand the terms and intended legal effect of CC0,
  and hereby voluntarily elect to apply it to this work.

  Work Name (UUID)     : $UUID
  Work MD5 HashCode    : $MD5
  My SoMLPR engine ID  : $ENGINEID
  My Email (optional)  : $EMAIL

  CC0 license text     : https://creativecommons.org/publicdomain/zero/1.0/
  """
    identifier = uuid.uuid4()
    waiver = template.replace('$UUID', str(identifier))
    waiver = waiver.replace('$MD5', hashlib.md5(im.astype("uint8")).hexdigest())
    waiver = waiver.replace('$ENGINEID', config.engine_id())
    waiver = waiver.replace('$EMAIL', config.email() or '')
    waiver = digitally_sign(waiver)
    waiver += '\n'
    if not _str_pubkey:
        with open(fn_cert_pub, 'rb') as f:
            pub_key = cryptography.x509.load_pem_x509_certificate(f.read(), backend=default_backend()).public_key()
        _str_pubkey = (pub_key.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
                      .decode('utf-8'))
    waiver += _str_pubkey
    waiver += '---------------------------------------------------------------------------'
    # print('verified : ', verify(waiver))  # for testing only
    return identifier, waiver


def get_server_certificate() -> str:
    """ fetch the server certificate (public part) used for waiver signing  ( buffered )"""
    global _srv_cert
    if _srv_cert:
        return _srv_cert
    try:
        with open(fn_cert_pub, 'rb') as f:
            cert = cryptography.x509.load_pem_x509_certificate(f.read(), backend=default_backend())
            _srv_cert = cert.public_bytes(serialization.Encoding.PEM).decode('utf-8')
            return _srv_cert
    except Exception as ex:  # noqa
        return f'ERROR fetching certificate from file - {ex}'

    # endregion


# endregion


# region Geolocate Country Code by Ip

async def geolocate() -> str | None:
    """ check 3 different ip geolocator services and retrieve country name + code"""

    async def geo1() -> tuple[str] | None:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get('https://ipinfo.io/json') as response:
                    data = await response.json()
                    return data.get('country', None)
        except:  # noqa
            return None

    async def geo2() -> tuple[str, str] | None:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get('http://ip-api.com/json') as response:
                    data = await response.json()
                    return data.get('countryCode', None), data.get('country', None)
        except:  # noqa
            return None

    async def geo3() -> tuple[str, str] | None:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get('http://www.geoplugin.net/json.gp') as response:
                    data = await response.json()
                    return data.get('geoplugin_countryCode', None), data.get('geoplugin_countryName', None),
        except:  # noqa
            return None

    ''' function entry point  '''
    try:
        coros = [geo1(), geo2(), geo3()]
        tasks = asyncio.gather(*coros)
        await asyncio.wait_for(tasks, 5)
        result = tasks.result()
        return str(result)
    except:  # noqa
        return None

# endregion
