<# 
.NOTES
	===========================================================================
	 Created by:   	Jakub Marczewski (j.m.marczewski@gmail.com)
	 Organization: 	SoM LPR 
	 Filename:     	create_ssl_certificates.ps1
	 License:		MIT < https://opensource.org/licenses/MIT >
	===========================================================================
.SYNOPSIS

Create SSL certificate chain for GRPC and REST ( PowerShell )

.DESCRIPTION

Creates 3 certificates in CurrentUser\My Store
	- SOMLPR CA  ( common ca certificate )
	- SOMPLR SRV ( the server certificate with COMPUTERNAME and default route associated IP in SAN )
	- SOMPLR CLT ( the client certificate with COMPUTERNAME and default route associated IP in SAN ) 
Exports in PEM format to files 
	* ca-cert.pem, ca-key.pem, 
	* server-cert.pem, server-key.pem, 
	* client-cert.pem and client-key.pem 
 in local folder 


.PARAMETER DNS
Coma separated list of DNS names the server will be accessed by 
	ie. mydomain.com, www.mydomain.com

.PARAMETER IP
Coma separated list of IP addresses the engine will be accessed at ie. 86.153.56.13

.PARAMETER Machine
Store CA Certificates in LocalMachine\My Store instead of CurrentUser\My

.PARAMETER Help
Print help

#>

<#  Note: Sign with PowerShell ( signing cert must be in CurrentUser\My and \Trusted Root.. )

Set-AuthenticodeSignature .\create_ssl_certificates.ps1 @(Get-ChildItem  -Path "Cert:\CurrentUser\My" | where { $_.subject -like "CN=SoM Code Signing" })[0]

#>


param (
    [Parameter(HelpMessage = "Coma separated list of DNS names the server will be accessed by ie. mydomain.com, www.mydomain.com")]
    [string[]]$DNS = '',
	[Parameter(HelpMessage = "Coma separated list of IP addresses the engine will be accessed at ie. 86.153.56.13")]
    [string[]]$IP = '',
    [Parameter(HelpMessage = "Store CA Certificates in LocalMachine\My Store instead of CurrentUser\My")]
    [switch]$Machine,
    [Parameter(HelpMessage = "Print Help")]
	[switch]$Help
)

if ($Help) {
    Get-Help $PSCommandPath -Detailed
    Exit
}

foreach ( $item in $DNS) {
Write-Output "Including DNS name $item in certificate SAN section"
}	
foreach ( $item in $IP) {
Write-Output "Including IP address $item in certificate SAN section"
}	



# check minimal PowerShell Version 
if ( ($PSVersionTable.PSVersion.Major -lt 5) -or (( $PSVersionTable.PSVersion.Major -eq 5) -and ($PSVersionTable.PSVersion.Minor -lt 1 ))){
	$major = $PSVersionTable.PSVersion.Major
	$minor = $PSVersionTable.PSVersion.Minor
	Write-Output "Minimum supported PowerShell version is 5.1"
	Write-Output "current: $major.$minor. Please update."
	Exit 
}

$Store = "Cert:\CurrentUser\My"
if ( $Machine) {
	$Store = "Cert:\LocalMachine\My"
}

Write-Output "Creating Self-Signed Certificates for SSL encryption..."


# set env:COMPUTERNAME, IPAddress routed to default gateway, and 0.0.0.0 as minimal Subject Alternative Names 
$default_gw = (Get-WmiObject -Class Win32_IP4RouteTable |
  where { $_.destination -eq '0.0.0.0' -and $_.mask -eq '0.0.0.0'} |
  Sort-Object metric1 | select nexthop).nexthop  
$nic = (Find-NetRoute -RemoteIPAddress $default_gw )[0].IPAddress

#Build Subject Alternative Names
$san = "DNS=$env:COMPUTERNAME"
foreach ( $entry in $DNS) {
	$san = $san + "&DNS=$entry"
}
$san = $san + "&IPAddress=$nic&IPAddress=0.0.0.0" 
foreach ( $entry in $IP) {
	$san = $san + "&IPAddress=$entry"
}

# Use existing CA Certificate if available 
$calist = Get-ChildItem  -Path $Store | where { $_.subject -eq "CN=SOMLPR CA" } | Sort-Object -Property NotBefore -Descending 

if ( !$calist ){
	# create new CA certificate to sign Server and Client Certificates
	Write-Output "Creating new CA certificate"
	$cacert = New-SelfSignedCertificate `
	-CertStoreLocation $Store `
	-KeyLength 4096 `
	-Subject "CN=SOMLPR CA" `
	-NotAfter (Get-Date).AddYears(20) `
	-FriendlyName "SoM LPR Certificate Authority Self-Signed" `
	-KeyUsage CertSign, CRLSign, DigitalSignature `
	-KeyProtection None `
	-KeySpec Signature `
	-KeyAlgorithm RSA `
	-HashAlgorithm SHA256 `
    -KeyExportPolicy Exportable `
	-TextExtension @("2.5.29.17={text}$san") `
	
} else {
	# use newest existing CA certificate to sign Server and Client Certificates
	$cacert = $calist[0]
	Write-Output "Using existing SomLpr CA certificate"
	Write-Output "'$($cacert.Subject)'  Issued=$($cacert.NotBefore)  Thumbprint=$($cacert.Thumbprint)  " 
}	


# create Server certificate for the local host

$srvcert = New-SelfSignedCertificate `
	-CertStoreLocation $Store `
	-Signer $cacert `
	-KeyLength 4096 `
	-Subject "CN=SOMLPR SRV" `
	-NotAfter (Get-Date).AddYears(20) `
	-FriendlyName "SoM LPR Server Self-Signed" `
	-KeyUsage DigitalSignature, KeyEncipherment, KeyAgreement `
	-KeyProtection None `
	-KeySpec Signature `
	-KeyAlgorithm RSA `
	-HashAlgorithm SHA256 `
    -KeyExportPolicy Exportable `
	-TextExtension @("2.5.29.17={text}$san") `
	

# create Client certificate for the local host

$cltcert = New-SelfSignedCertificate `
	-CertStoreLocation $Store `
	-Signer $cacert `
	-KeyLength 4096 `
	-Subject "CN=SOMLPR CLT" `
	-NotAfter (Get-Date).AddYears(20) `
	-FriendlyName "SoM LPR Local Client Self-Signed" `
	-KeyUsage DigitalSignature, KeyEncipherment, KeyAgreement `
	-KeyProtection None `
	-KeySpec Signature `
	-KeyAlgorithm RSA `
	-HashAlgorithm SHA256 `
    -KeyExportPolicy Exportable `
	-TextExtension @("2.5.29.17={text}$san") `


function Export-Pem($cert, $name) {
	 # Public key to Base64
	$CertBase64 = [System.Convert]::ToBase64String($cert.RawData, [System.Base64FormattingOptions]::InsertLineBreaks)
	# Private key to Base64
	$RSACng = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($cert)
	$KeyBytes = $RSACng.Key.Export([System.Security.Cryptography.CngKeyBlobFormat]::Pkcs8PrivateBlob)
	$KeyBase64 = [System.Convert]::ToBase64String($KeyBytes, [System.Base64FormattingOptions]::InsertLineBreaks)
	# Output to file
	$Key = @"
-----BEGIN PRIVATE KEY-----
$KeyBase64
-----END PRIVATE KEY-----
"@
	$Pem = @"
-----BEGIN CERTIFICATE-----
$CertBase64
-----END CERTIFICATE-----
"@
	$Key | Out-File -FilePath $name-key.pem -Encoding Ascii
	$Pem | Out-File -FilePath $name-cert.pem -Encoding Ascii
}
 
# Export Certificates 
 
 Export-Pem -cert $cacert -name "ca"
 Export-Pem -cert $srvcert -name "server"
 Export-Pem -cert $cltcert -name "client"
 
#remove Server and Client Certificates from Store ( keep CA in Store )
$srvcert | Remove-Item
$cltcert | Remove-Item

Write-Output ""  
Write-Output "Created Certificates:" 
if (!$calist){
	Write-Output "Thumbprint=$($cacert.Thumbprint) ; $($cacert.Subject)" 
}
Write-Output "Thumbprint=$($srvcert.Thumbprint) ; $($srvcert.Subject)" 
Write-Output "Thumbprint=$($cltcert.Thumbprint) ; $($cltcert.Subject)" 
Write-Output "all done."


# SIG # Begin signature block
# MIIFcAYJKoZIhvcNAQcCoIIFYTCCBV0CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUlTeSEMwmrptsBmDUYyef5NqS
# CnGgggMKMIIDBjCCAe6gAwIBAgIQW/+G0eRG5KpB5otfCQUomzANBgkqhkiG9w0B
# AQUFADAbMRkwFwYDVQQDDBBTb00gQ29kZSBTaWduaW5nMB4XDTI0MTIyMTE0NDky
# NFoXDTMwMTAxMDIzMDAwMFowGzEZMBcGA1UEAwwQU29NIENvZGUgU2lnbmluZzCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMmYmZfnBzaZpP4/8Q7We++t
# bKs435nPh0RCUf+KyVkNrgsg55DSpAt0rDmrD55SAs6MldS0/WiHpwf35So4yv9Y
# BikQznij4U8esbOUBiMA6q16kHoU6Z0FPz4A5z8i2FWjV4SSy0SAVLnCZkQ3g34i
# 1+sC6fAi5nYJzopEZ8eoZMQfhEP5M1IxYmBIGoAcuALYb2PPnYamGvK/SQzdvTqd
# sJnp2xz0eZ3jFEC5hi/RtHVhnYCs/U+rLnBaD97s/15u55U3ItOSrjVVhvrX89Ks
# YxOBYNFxe2WxZKew8W8fe8Sr/eOEy87j7bfTHoDZI9rVGFCCPLAG05iZ9S98DpkC
# AwEAAaNGMEQwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMB0G
# A1UdDgQWBBSZvZgCCajqdvjZ5d5ly/7EqkNEBTANBgkqhkiG9w0BAQUFAAOCAQEA
# DhTdcK9CqcWTtVJ32NaLMRhyYZC2REEJm734FFLjgrLayN4l7g5nKw+VFXoct3vZ
# DMmaQAI4mNdxUkPiwb+/5Sks7vGYDIHMyIPacccrfq3ta/ajOQ97zOF5rBGhYuJQ
# S+RXkkgvvABYf6rH63U0WEdO2UstcpsZwIqVN48K8FHpEhSg5vYoJY+C9FYAC0AK
# HUqL/mmFsxUMkbUtz5pOwFRwMFBK9z24p3FFy6OzmKvHo7k0BXNzp2IlfrWkZJ3E
# 7DwK95X/D+tj8tobU2JIKLYc8pIvzVDRHm6gGKd3pZHQn4mh58JioWDQjNTO3v0o
# k0jERbxQTsGCk/KF5dxwezGCAdAwggHMAgEBMC8wGzEZMBcGA1UEAwwQU29NIENv
# ZGUgU2lnbmluZwIQW/+G0eRG5KpB5otfCQUomzAJBgUrDgMCGgUAoHgwGAYKKwYB
# BAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAc
# BgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUlMBN
# G0fsGBYdjbrtQE15L4RrZt4wDQYJKoZIhvcNAQEBBQAEggEALFG0EEn+tHFc/VU5
# 7uFAv8d2Z5vyu8V+vHmpDxVw+na3ZogxmH/6DqQZtqIEQj4Yo5MdIoAV2jO9KqNi
# xl8CqEqGBwrCzhA7dt1Ci0afo0l2T/Dn62YKkdHzioeKq/l7KZmgBQ8yicMzcWH6
# 3oBfa2pSfxxzchK57vNbkkqtBvQEJ14C0yTKmOaZ6HM4QeHbIL+zpAruVlMOoR4m
# GmTHxFeWWGrBL+kMlufV7PsISDHFqL1vB/jDNrYdfTBbAcplUj6ygiExoAo20WGA
# Ifp1VFu6sx/HrDhTCsvcS7VXDVC2SD0g1j1FXySJ7Q411+zKOWaV5Y8EAlNGMTmY
# 7q9IBg==
# SIG # End signature block
