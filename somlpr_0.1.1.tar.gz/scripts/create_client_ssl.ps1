<# 
.NOTES
	===========================================================================
	 Created by:   	Jakub Marczewski (j.m.marczewski@gmail.com)
	 Organization: 	SoM LPR 
	 Filename:     	create_client_ssl.ps1
	 License:		MIT < https://opensource.org/licenses/MIT >
	===========================================================================
.SYNOPSIS

Create SSL certificate for a new SoM LPR client ( PowerShell )

.DESCRIPTION

Creates a new SSL pem certificate file for encrypted SSL communication with the SoM LPR engine via GRPC 
Created certificate allows for client side verification  ( SSL setting 2 in config.toml file )
	
Exports in PEM format to files 
	* client-cert.pem and client-key.pem 
 in local folder. If the files already exist, a suffix may be added
 
.PARAMETER IP
Coma separated list of IP addresses of the client ( private and/or public IP's as seen by the server )


.PARAMETER DNS
Coma separated list of DNS names the client will using when connecting to the server


.PARAMETER Help
Print help

#>

<#  Note: Sign with PowerShell ( signing cert must be in CurrentUser\My and \Trusted Root.. )


Set-AuthenticodeSignature .\create_client_ssl.ps1 @(Get-ChildItem  -Path "Cert:\CurrentUser\My" | where { $_.subject -like "CN=SoM Code Signing" })[0]


#>

param (
    [Parameter(HelpMessage = "Coma separated list of DNS names the client will using when connecting to the server")]
    [string[]]$DNS = @(),
	[Parameter(HelpMessage = "Coma separated list of IP addresses of the client ( private and/or public IP's as seen by the server )")]
    [string[]]$IP = @(),
    [Parameter(HelpMessage = "Print Help")]
	[switch]$Help
)


if ($Help) {
    Get-Help $PSCommandPath -Detailed
    Exit
}

# check minimal PowerShell Version ( 5.1 )
if ( ($PSVersionTable.PSVersion.Major -lt 5) -or (( $PSVersionTable.PSVersion.Major -eq 5) -and ($PSVersionTable.PSVersion.Minor -lt 1 ))){
	$major = $PSVersionTable.PSVersion.Major
	$minor = $PSVersionTable.PSVersion.Minor
	Write-Output "Minimum supported PowerShell version is 5.1"
	Write-Output "current: $major.$minor. Please update."
	Exit 
}

function IsValidIPv4Address ($ip) {
    return ($ip -match "^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$" -and [bool]($ip -as [ipaddress]))
}

function IsValidDns ($dns) {
    return ($dns -match "^(([a-zA-Z]{1})|([a-zA-Z]{1}[a-zA-Z]{1})|([a-zA-Z]{1}[0-9]{1})|([0-9]{1}[a-zA-Z]{1})|([a-zA-Z0-9][a-zA-Z0-9-_]{1,61}[a-zA-Z0-9]))\.([a-zA-Z]{2,6}|[a-zA-Z0-9-]{2,30}\.[a-zA-Z]{2,3})$")
}

function Export-Pem($cert, $name) {
	 # Public key to Base64
	$CertBase64 = [System.Convert]::ToBase64String($cert.RawData, [System.Base64FormattingOptions]::InsertLineBreaks)
	# Private key to Base64
	$RSACng = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($cert)
	$KeyBytes = $RSACng.Key.Export([System.Security.Cryptography.CngKeyBlobFormat]::Pkcs8PrivateBlob)
	$KeyBase64 = [System.Convert]::ToBase64String($KeyBytes, [System.Base64FormattingOptions]::InsertLineBreaks)
	# Output to file
	$Key = @"
-----BEGIN PRIVATE KEY-----
$KeyBase64
-----END PRIVATE KEY-----
"@
	$Pem = @"
-----BEGIN CERTIFICATE-----
$CertBase64
-----END CERTIFICATE-----
"@
	$Key | Out-File -FilePath $name-key.pem -Encoding Ascii
	$Pem | Out-File -FilePath $name-cert.pem -Encoding Ascii
}


$adr_list = @()
if ( ($IP.Length -eq 0) -and ($DNS.Length -eq 0)){
 Write-Output "Please specify minimum 1 client IP address/DNS name and Press Enter."
 Write-Output "Press Enter with no input when done adding all."
 do
 {
   Clear-Host 
   if ( $adr_list.Length -gt 0 ){
    Write-Output "Press Enter with no input when done adding all."   
    Write-Output "`nAddresses so far:`n"
    write-Output $adr_list 
    write-Output ""
   }
   else {
    Write-Output "Please specify minimum 1 client IP address/DNS name and Press Enter."
	Write-Output "Press Enter with no input when done adding all."
   }
   $adr = Read-Host -Prompt ip/dns
   if ($adr) {
	   
	   # validate input as IPAddress
	   if ( IsValidIPv4Address -ip $adr ){
		$adr_list += " (ip) $adr"
		$IP += $adr
		continue
	   }
	   
	   # validate as DNS
	   if ( IsValidDns -dns $adr ){
		$adr_list += "(dns) $adr" 
		$DNS += $adr
		continue
	   }
	   
	   # do not accept input 
	   Write-Output "WRONG FORMAT ! -- use '1.2.3.4' or 'foo.bar.com' notation"
	   Start-Sleep -Seconds 2.5
   }
 }
 until (!$adr -and $adr_list.length -gt 0 )	
}

# build SAN entry list 
$san = ""
foreach ( $entry in $DNS) {
	$san = $san + "&DNS=$entry"
}
$san = $san + "&IPAddress=0.0.0.0" 
foreach ( $entry in $IP) {
	$san = $san + "&IPAddress=$entry"
}
$san = $san.Substring(1)

Write-Output "Creating Self-Signed Client Certificate for SSL encryption..."

#look for CA certificates in these locations
$locations =@("./", "Cert:\CurrentUser\My", "Cert:\LocalMachine\My")

foreach ( $loc in $locations ){
	
  if ( $loc.StartsWith("Cert:\") ){
	# Get Certificate from a Certificate Store
	$calist = Get-ChildItem  -Path $loc | where { $_.subject -eq "CN=SOMLPR CA" } | Sort-Object -Property NotBefore -Descending
	if ( !$calist ){
		$cacert = $calist[0]
		Write-Output "Using CA certificate from $loc`n"
		Write-Output "'$($cacert.Subject)'  Issued=$($cacert.NotBefore)  Thumbprint=$($cacert.Thumbprint)`n" 
		break
	}
  } else {
    # load from directory
	$path_cer = Join-Path -Path $loc -ChildPath "ca-cert.pem"
	$path_key = Join-Path -Path $loc -ChildPath "ca-key.pem"
	if ( (!(Test-Path $path_cer -PathType Leaf)) -or (!(Test-Path $path_key -PathType Leaf)) ) {
		# ca-cert.pem and/or ca-key.pem not found.
		continue
	}
	# add private key to certificate and convert to bytes
	$txt_cer =  Get-Content -Path $path_cer   
	$txt_key =  Get-Content -Path $path_key
	$plain = $txt_cer + $txt_key
	$bytes = [System.Text.Encoding]::UTF8.GetBytes($plain)
	#load certificate from bytes
	$cacert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate
	$cacert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($bytes)  
	if ( $cacert ){
		Write-Output "Using CA certificate from ca-cert.pem/ca-key.pem files found in $loc`n"
		Write-Output "'$($cacert.Subject)'  Issued=$($cacert.NotBefore)  Thumbprint=$($cacert.Thumbprint)`n" 
		break;
	}
  }
}

# check that there is a CA certificate found
if (!$cacert) {
	Write-Output "Failed to find SOM-LPR CA certificate in these locations`n"
	write-Output $locations
	Write-Output "`nOne solution to this problem is re-creating the missing certificate(s) by running ./create_ssl_certificates.ps1 script"
	Exit 1
}
  
# Allow user to Change default subject
$subject = "CN=SOMLPR CLT"
Write-Output "Input a Subject line to the Certificate or press Enter to use default:`n"
Write-Output "  default: $subject `n"
$custom_subject = Read-Host -Prompt Subject
if ($custom_subject) {
	if (!($custom_subject -match "CN=")){
		$custom_subject = "CN=" + $custom_subject
	}
	$subject = $custom_subject
}

# Allow user to Change default friendly name
$friendly = "SoM LPR Client Self-Signed"
Write-Output "Input a Friendly Name to the Certificate or press Enter to use default:`n"
Write-Output "  default Friendly Name: $friendly `n"
$custom_friendly = Read-Host -Prompt Subject
if ($custom_friendly) {
	$friendly = $custom_friendly
}

# create Client certificate for given ip/dns entries

Write-Output "Creating Self-Signed Client Certificate for SSL encryption..."
  
	$cltcert = New-SelfSignedCertificate `
	-CertStoreLocation "Cert:\CurrentUser\My"`
	-Signer $cacert `
	-KeyLength 4096 `
	-Subject $subject `
	-NotAfter (Get-Date).AddYears(20) `
	-FriendlyName $friendly `
	-KeyUsage DigitalSignature, KeyEncipherment, KeyAgreement `
	-KeyProtection None `
	-KeySpec Signature `
	-KeyAlgorithm RSA `
	-HashAlgorithm SHA256 `
    -KeyExportPolicy Exportable `
	-TextExtension @("2.5.29.17={text}$san") `

# move current client-cert.pem and client-key.pem to client-cert.pem.<Index> and client-key.pem.<Index>
if ( Test-Path ".\client-cert.pem" -PathType Leaf ){
	$index = 0
	do {
		$index = $index + 1
	} until ( !(Test-Path ".\client-cert.pem.$index" -PathType Leaf) )
	# Move old client-cert.pem & client-key.pem to new files
	Rename-Item -Path ".\client-cert.pem" -NewName ".\client-cert.pem.$index"
	if ( Test-Path ".\client-key.pem.$index" -PathType Leaf ) {
		# remove old indexed key file if a stale one was lying around
		Remove-Item -Path ".\client-key.pem.$index"
	}
	Rename-Item -Path ".\client-key.pem" -NewName ".\client-key.pem.$index"
	Write-Output "`nMoved existing   .\client-cert.pem   file to   .\client-cert.pem.$index"
	Write-Output "Moved existing    .\client-key.pem   file to   .\client-key.pem.$index`n"
}	

#export new certificate to client-cert.pem and client-key.pem files 
Export-Pem -cert $cltcert -name "client"

#Remove client cert from Personal Store
$cltcert | Remove-Item

Write-Output "Created new .\client-cert.pem and .\client-key.pem files with certificate and key:`n"
Write-Output "Thumbprint    = $($cltcert.Thumbprint)" 
Write-Output "Subject       = $($cltcert.Subject)" 
Write-Output "Friendly Name = $($cltcert.FriendlyName)" 
Write-Output "SAN           = $($san)`n" 

Write-Output @"
  * Copy/Move
      
	     client-cert.pem  ,  client-key.pem   ( 2 files from this directory  )
	   
	
  * Copy 

	      ca-cert.pem  ( 1 file from server main directory )

   into your SoM LPR clients installation directory on the client machine.	
	   
"@


Write-Output "all done."

# SIG # Begin signature block
# MIIFcAYJKoZIhvcNAQcCoIIFYTCCBV0CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU/5kOdnzHxbg2FkLvB0wq1ync
# A92gggMKMIIDBjCCAe6gAwIBAgIQW/+G0eRG5KpB5otfCQUomzANBgkqhkiG9w0B
# AQUFADAbMRkwFwYDVQQDDBBTb00gQ29kZSBTaWduaW5nMB4XDTI0MTIyMTE0NDky
# NFoXDTMwMTAxMDIzMDAwMFowGzEZMBcGA1UEAwwQU29NIENvZGUgU2lnbmluZzCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMmYmZfnBzaZpP4/8Q7We++t
# bKs435nPh0RCUf+KyVkNrgsg55DSpAt0rDmrD55SAs6MldS0/WiHpwf35So4yv9Y
# BikQznij4U8esbOUBiMA6q16kHoU6Z0FPz4A5z8i2FWjV4SSy0SAVLnCZkQ3g34i
# 1+sC6fAi5nYJzopEZ8eoZMQfhEP5M1IxYmBIGoAcuALYb2PPnYamGvK/SQzdvTqd
# sJnp2xz0eZ3jFEC5hi/RtHVhnYCs/U+rLnBaD97s/15u55U3ItOSrjVVhvrX89Ks
# YxOBYNFxe2WxZKew8W8fe8Sr/eOEy87j7bfTHoDZI9rVGFCCPLAG05iZ9S98DpkC
# AwEAAaNGMEQwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMB0G
# A1UdDgQWBBSZvZgCCajqdvjZ5d5ly/7EqkNEBTANBgkqhkiG9w0BAQUFAAOCAQEA
# DhTdcK9CqcWTtVJ32NaLMRhyYZC2REEJm734FFLjgrLayN4l7g5nKw+VFXoct3vZ
# DMmaQAI4mNdxUkPiwb+/5Sks7vGYDIHMyIPacccrfq3ta/ajOQ97zOF5rBGhYuJQ
# S+RXkkgvvABYf6rH63U0WEdO2UstcpsZwIqVN48K8FHpEhSg5vYoJY+C9FYAC0AK
# HUqL/mmFsxUMkbUtz5pOwFRwMFBK9z24p3FFy6OzmKvHo7k0BXNzp2IlfrWkZJ3E
# 7DwK95X/D+tj8tobU2JIKLYc8pIvzVDRHm6gGKd3pZHQn4mh58JioWDQjNTO3v0o
# k0jERbxQTsGCk/KF5dxwezGCAdAwggHMAgEBMC8wGzEZMBcGA1UEAwwQU29NIENv
# ZGUgU2lnbmluZwIQW/+G0eRG5KpB5otfCQUomzAJBgUrDgMCGgUAoHgwGAYKKwYB
# BAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAc
# BgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUXaMy
# YO9eLEQAsZOukUpmnLS8CLIwDQYJKoZIhvcNAQEBBQAEggEALebGiZL2I8vykMXu
# 0DcbYy8CtESA86VypaSiE39qZoFyzzJgtLGu5EJLxGFauGo7JfmQLQfsitphZVqS
# ADbbzQTIiHbg1h4TtH3Z6QkR4AYVFyn1TcK5eEEy6uXfIc4w1WjT1o1BkyZUbDtw
# QoOaDd9mHtUW/igaHjqEbveMeXewWKYzI7bAR0H0BzKJ89OuU+iW8hzaWfB3Tv4E
# s9USCWHp2JQQJ18UdEUssdLbM105X5pKRlJ0iQMkySOnf0n2mQ4tGLlaO6HFCtHv
# UJp6Hdvk1c48CPG4Emy+Jf9lqAgQlwlVhG9Ab+mlVfQr7uu7emeoTB9LB7zoY5Fj
# QyREBA==
# SIG # End signature block
