# !/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.12"
# dependencies = [
#      'loguru', 'tqdm', 'requests'
# ]
# ///

"""

 Check and install/update the newest versions of the weight files ( the neural network 'brains' )

 Run this script periodically to check for new versions
 ( usually versions retrained on more images ) of the network brains.

 command line options

  -y / --yes : don't prompt for confirmation of download ( a full set of files might be > 100 Mb )

  -c / --check : display new available versions without downloading them

 command line options used mainly for development

  - a / --all : download all available models ( including all country specific models )

  - o / --out : download to different directory than ./brains

  - f / --force  :  force download ( in case of corrupted local files )

  - u / --url  : fetch model list ( the brains.toml file ) from alternative url


"""

import os
import sys
import argparse
import hashlib
import toml
import requests
from loguru import logger
from tqdm import tqdm

__copyright__ = "Copyright 2024, Jakub Marczewski"
__license__ = 'MIT ( https://opensource.org/licenses/MIT )'

parser = argparse.ArgumentParser(description=" Check and install the newest versions of the weight files "
                                             "( the 'brains' of the neural networks )' ")
group = parser.add_mutually_exclusive_group()
group.add_argument('-f', '--force', help="force (re)download of brains", action="store_true")
group.add_argument('-c', '--check', help="check for updates but don't update", action="store_true")
parser.add_argument('-a', '--all', help="download all available models", action="store_true")
parser.add_argument('-y', '--yes', help="don't prompt for confirmation of large download", action="store_true")
parser.add_argument('-o', '--out', help="download to different directory than brains",
                    nargs='?', type=str, metavar='directory', default=None)
parser.add_argument('-u', '--url', help="alternative brains.toml url",
                    nargs='?', type=str, metavar='url', default=None)

args = parser.parse_args()

# the base folder for the engine ( 1 level up from this 'scripts' folder )
base_path = os.path.normpath(os.path.join(os.path.dirname(os.path.realpath(__file__)), '../'))

# main config file ( config/config.toml )cd
config_file = os.path.join(base_path, 'config', 'config.toml')

# file with all available neural networks file ( brains/brains.toml )
brain_file = os.path.join(base_path, 'brains', 'brains.toml')

# locations ( urls ) where the brains.toml file can be found
brain_file_urls = ['https://github.com/jmarczewski/testproj/raw/refs/heads/main/brains/brains.toml']


def download(url: str, filename: str, chunk_size: int = 1024):
    """ synchronously download an url resource to a local file ( with progress bar ) """
    resp = requests.get(url, stream=True)
    total = int(resp.headers.get('content-length', 0))
    with open(filename, 'wb') as file, tqdm(
            desc=filename,
            total=total,
            unit='iB',
            unit_scale=True,
            unit_divisor=1024,
            file=sys.stdout,
            colour='green',

    ) as bar:
        for data in resp.iter_content(chunk_size=chunk_size):
            size = file.write(data)
            bar.update(size)


def check_url_file_exists(url: str) -> bool:
    """ send a HEAD request to the url to check if resource is available on the server"""
    try:
        r = requests.head(url, allow_redirects=True)
        if r.status_code == 200:
            return True
        elif r.status_code == 404:
            logger.warning(f'File missing (code 404): {url}')
            return False
        else:
            logger.warning(f'Url check error (code {r.status_code}): {url}')
    except Exception as ex:
        logger.error(f'{type(ex)} checking url {url}')
    return False


# def load_current_brains_toml_file() -> dict:
#     try:
#         if not os.path.exists(brain_file):
#             logger.info('no local brains/brains.toml file found.')
#             return {'model': []}
#         return toml.load(brain_file)
#     except Exception as ex:
#         logger.info(f'{type(ex)} loading local brains/brains.toml.')
#         return {'model': []}


def load_config_toml_file() -> dict:
    try:
        if not os.path.exists(config_file):
            logger.info('no config/config.toml file found.')
            return {'model': []}
        return toml.load(config_file)
    except Exception as ex:
        logger.info(f'{type(ex)} loading config/config.toml.')
        return {'model': []}


def download_remote_brains_toml_file() -> dict:
    """ get the list of available model weights from github """
    logger.info('Downloading newest list of models ...')
    fn_new_toml = os.path.join(base_path, 'brains', 'brains.toml')
    for idx, url in enumerate(brain_file_urls):
        try:
            if not check_url_file_exists(url):
                if idx == len(brain_file_urls) - 1:
                    raise FileNotFoundError('failed to find brain.toml in all checked urls.')
                continue
            download(url, fn_new_toml)
            break
        except Exception as ex:
            if idx == len(brain_file_urls) - 1:
                logger.error(f'Failed to download current list of neural network brains ({type(ex)}). Exiting')
                exit(1)
    try:
        data = toml.load(fn_new_toml)
    except Exception as ex:
        logger.error(f'Failed to parse downloaded brains/brains.toml file ({type(ex)}). Exiting')
        exit(2)
    return data


def get_md5_hash(filename: str) -> str | None:
    """ get md5 hash of file """
    try:
        with open(filename, 'rb') as f:
            d = f.read()
            h = hashlib.md5(d).hexdigest()
            return h
    except Exception as ex:  # noqa
        return None


def sizeof_fmt(num, suffix="B"):
    """ bytes to human-readable format """
    for unit in ("", "Ki", "Mi", "Gi", "Ti", "Pi", "Ei", "Zi"):
        if abs(num) < 1024.0:
            return f"{num:3.1f} {unit}{suffix}"
        num /= 1024.0
    return f"{num:.1f} Yi{suffix}"


def human_size_to_bytes(size: str) -> float:
    """ human-readable file size to (approximate) bytes """
    try:
        tokens = size.strip().split(' ')
        value = float(tokens[0])
        match tokens[1]:
            case 'KiB':
                return value * 1024
            case 'MiB':
                return value * 1024 * 1024
            case 'GiB':
                return value * 1024 * 1024 * 1024
            case 'TiB':
                return value * 1024 * 1024 * 1024 * 1024
            case _:
                return value
    except:  # noqa
        return 0


def run_standard_update_pipeline():
    """ the main usage case for this script - update weight files that are used on this machine and
    are not in the newest version """
    data_new = download_remote_brains_toml_file()['model']
    data_cfg = load_config_toml_file()['model']
    list_new = [x['name'] for x in data_new]
    list_cfg = [x['name'] for x in data_cfg]
    marked = []

    def mark(m, i):
        """ mark (m)model and (i)ndex for download """
        if (m, i) not in marked:
            marked.append((m, i))

    if args.all:
        list_cfg = list_new.copy()
    for model in data_new:
        try:
            if 'default' not in model.get('tags', []) and model['name'] not in list_cfg:
                continue
            ''' process model '''
            for idx, file in enumerate(model['files']):
                fn = os.path.join(base_path, 'brains', model['path'], file)
                md5_new = model['hashes'][idx]
                md5_cur = get_md5_hash(fn)
                ''' local file is missing  '''
                if md5_cur is None:
                    logger.opt(colors=True).info(f'<red>missing    </> <magenta>{model["name"]}[{idx}]</> '
                                                 f'( {model["sizes"][idx]}" )')
                    if args.check:
                        continue
                    mark(model, idx)
                    continue
                ''' local file is up to date '''
                if md5_new[idx] == md5_cur[idx]:
                    logger.opt(colors=True).info(f'<green>up to date </> <magenta>{model["name"]}[{idx}]</> '
                                                 f'( {model["sizes"][idx]}" )')
                    if args.force:
                        ''' force of download even if Md5 seams the same'''
                        mark(model, idx)
                    continue
                ''' files are different '''
                if args.check:
                    ''' no update, just show '''
                    logger.opt(colors=True).info(f'model <red>out of date</> <magenta>{model["name"]}[{idx}] </> '
                                                 f'( {model["sizes"][idx]} )')
                    continue
                mark(model, idx)

        except Exception as ex:
            logger.error(f'Failed processing model {model["name"]}: {ex}', ex)
            raise
    ok = 0
    err = 0
    if len(marked) == 0:
        logger.info('No new files to download.\ndone.')
        exit(0)
    estimated_bytes_to_download = 0.0
    for m, i in marked:
        estimated_bytes_to_download += human_size_to_bytes(m['sizes'][i])
    logger.info(f'Estimated bytes to download: {sizeof_fmt(estimated_bytes_to_download)}')
    if not args.yes:
        confirm = input('Continue? (y/n) ')
        if confirm != 'y':
            logger.info('Aborted')
            exit(0)
    logger.info(f'Downloading {sizeof_fmt(estimated_bytes_to_download)} in {len(marked)} files...')
    for m, i in marked:
        ''' ensure directory for destination file exists'''
        brain_dir = 'brains' if args.out is None else args.out
        fn = os.path.join(base_path, brain_dir, m['path'], m['files'][i])
        if not os.path.exists(os.path.dirname(fn)):
            os.makedirs(os.path.dirname(fn))
        for idx, base_url in enumerate(m['urls']):
            try:
                url = f'{base_url.strip("/")}/{m["path"].strip("/")}/{m["files"][i]}'
                if not check_url_file_exists(url):
                    raise FileNotFoundError(f"the URL resource does not exist")
                download(url, fn)
                ok += 1
                break
            except Exception as ex:
                if idx == len(m['urls']) - 1:
                    msg = (f'<red>Failed downloading</> model <magenta>{m["name"]}</>, '
                           f'file <magenta>{m["files"][i]}</>: {ex}')
                    logger.opt(colors=True).error(msg, ex)
                    err += 1
    logger.info(f'done. {ok} files downloaded, {err} errors occurred.')
    logger.info('done.')


def main():
    logger.configure(handlers=[{"sink": sys.stdout, "level": "DEBUG", "format": "{message}"}])
    logger.info(f'Engine base directory is {base_path}')
    if args.url:
        global brain_file_urls
        brain_file_urls = [args.url]
    ''' standard update of weights files '''
    run_standard_update_pipeline()


if __name__ == '__main__':
    main()

basedir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'touch')