<# 
.NOTES
	===========================================================================
	 Created by:   	Jakub Marczewski (j.m.marczewski@gmail.com)
	 Organization: 	SoM LPR 
	 Filename:     	win64.ps1
	 License:		MIT < https://opensource.org/licenses/MIT >
	===========================================================================
.SYNOPSIS

Register/Unregister SoM Lpr Engine instances on the list of Windows Installed Apps and as a Service(s) 

.DESCRIPTION
This script handles Windows OS specific tasks :

1) Creates o or Removes entries from HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall 
   of HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall to add or remove the 
   SoM Lpr engine from the list of installed Apps.
   Supports multiple instances of Installations in different folders via the #1, #2 suffix

2) Registers / Unregister the SoMLpr Engine as a Windows Service
   Supports multiple instances of Installations in different folders via the #1, #2 suffix 

3) Show Installed locations and Service Statuses

.PARAMETER Registry
# Action to take: Add|Update/Remove from registry
- Add
- Remove

.PARAMETER Service
# Action to take: Install/Uninstall as Windows Service
- Add
- Remove

.PARAMETER Machine
Install for All Users ( required elevation, makes a difference only with Registry )


.PARAMETER UrlAcl
# Action to take: Add / Remove / Check Purge on URL ACL lists 
- Add  = add a reservation of the form $Protocol://*:{$Port}/ ie. https://*58181/ for user \Everyone
- Remove = remove an existing reservation 
- Check  = check if reservation exists in url acl list
- Purge = Remove all added reservations ( part of uninstall procedure )

.PARAMETER Port
# Port number to use for UrlAcl.
Note: Used only with UrlAcl command

.PARAMETER Https
# Use https protocol in url acl calls. If not present http will be used
Note: Used only with UrlAcl command


.PARAMETER Help
Show Help 
#>


<#  Note: Sign with PowerShell ( signing cert must be in CurrentUser\My and \Trusted Root.. )


Set-AuthenticodeSignature .\win64.ps1 @(Get-ChildItem  -Path "Cert:\CurrentUser\My" | where { $_.subject -like "CN=SoM Code Signing" })[0]


#>

param (
    [Parameter(HelpMessage = "Action to take: Add|Update/Remove from registry")]
    [ValidateSet('Add','Remove')]
    [string[]]$Registry = @(),
    [Parameter(HelpMessage = "Action to take: Install/Uninstall as Windows Service. Requires Elevation")]
    [ValidateSet('Add','Remove')]
    [string[]]$Service = @(),
	[Parameter(HelpMessage = "Add as App installed for all users instead of Current User (HKLM instead of HKCU). Requires Elevation")]
    [switch]$Machine,
	[Parameter(HelpMessage = "Action to take on URL ACL list. Add & Remove require Elevation")]
    [ValidateSet('Add','Remove', "Check", "Purge")]
    [string[]]$UrlAcl,
	[Parameter(HelpMessage = "Port number for use in UrlAcl command")]
    [int]$Port,
	[Parameter(HelpMessage = "Use https protocol in UrlAcl command instead of http")]
    [switch]$Https,
    [Parameter(HelpMessage = "Print Help")]
	[switch]$Help
)

# parameters used
$install_folder = (get-item $PSScriptRoot ).parent.FullName  # installation folder is the parent folder of this script location
$publisher = 'Jakub Marczewski'


# ############  Helper Methods ##############


function EnsureElevated {
    # Self-elevate the script if require
    if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] 'Administrator')) {
       if ([int](Get-CimInstance -Class Win32_OperatingSystem | Select-Object -ExpandProperty BuildNumber) -ge 6000) {
           $CommandLine = "-File `"" + $MyInvocation.MyCommand.Path + "`" " + $MyInvocation.UnboundArguments
           $exit_code = (Start-Process -FilePath PowerShell.exe -Verb Runas -Wait -PassThru -ArgumentList $CommandLine).ExitCode
           if ( $exit_code -eq 0) { Write-Output "Success."}
           else {Write-Error "Failure ($exitcode)."}
           Exit $exitcode
   }}
}


function GetEveryOneNameFromSID {
    return ([wmi]"Win32_SID.SID='S-1-1-0'").AccountName
}


# ############  Windows Registry Handling  ##############

function FindRegistryEntry {
    # find the entry with $install_folder if exists return it
    $app_list =  @(Get-ChildItem -Path $reg_uninstall | Where-Object Name -match 'SOMLPR\b|SOMLPR\d+\b')
    foreach ( $key in $app_list) {
        if ( $install_folder -eq (Get-ItemProperty -Path "Registry::$key" -Name "InstallLocation").InstallLocation) {
           return "Registry::$key"
        }
    }
    return $null
}

function FindMaxRegistryInstanceIndex {
    # get an installation number #X suffix for new installation in more than one installation directories
    # search both HKLM & HKCU for 'SOMLPR\b|SOMLPR\d+\b' pattern
    $index = -1
    foreach ( $root in @('Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                         'Registry::HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall')){
        $app_list =  @(Get-ChildItem -Path $root | Where-Object Name -match 'SOMLPR\b|SOMLPR\d+\b')
        foreach ( $key in $app_list) {
            try {
            $idx = (Get-ItemProperty -Path "Registry::$key" -Name "InstanceIndex").InstanceIndex
            if ( $index -lt $idx) {
               $index = $idx
            } 
        } catch { } # ignore malformed entries
        }                   
    }
    return $index
}

function AddToRegistry {
    #determine key name
    $existing = FindRegistryEntry
    if ( $null -ne $existing){
        Write-Output("SoMLpr engine at location $install_folder already registered as $existing")
        $som_reg_path = $existing
    } else {
        $idx = FindMaxRegistryInstanceIndex
        $idx = $idx + 1
        $som_reg_path = "$reg_uninstall\SOMLPR$idx"
        $display_name = 'Society Of Mind (SoM) LPR Engine'
        if ( $idx -gt 0){
            $display_name = $display_name + " #" + $idx
        } 
    }
    # determine SoM Lpr version
    try {
        # parse from .version file in install directory
        $version = Get-Content -Path $install_folder\.version
        $version = [Regex]::Matches($version, '[\d\.]+');
        $version = [Version]::Parse($version[0])
    }
    catch {
        $version = [Version]::new(0,0,0,0)
    }
    # determine approximate size of installation in bytes
    $install_size = (Get-ChildItem -Path $install_folder -Recurse | Measure-Object -Property Length -Sum).Sum
    $install_size = [int]($install_size / 1024)

    if ( Test-Path -Path $som_reg_path ) {
        # the app is already registered ( let's update the data )
        Set-ItemProperty -Path $som_reg_path -Name "InstallDate" -Value (Get-Date -Format "yyyyMMdd") 
        Set-ItemProperty -Path $som_reg_path -Name "EstimatedSize" -Value $install_size
        if ($version.Major -gt 0) {
            Set-ItemProperty -Path $som_reg_path -Name "Version" -Value "$version"
            Set-ItemProperty -Path $som_reg_path -Name "DisplayVersion" -Value "$version"
            Set-ItemProperty -Path $som_reg_path -Name "VersionMajor" -Value $version.Major 
            Set-ItemProperty -Path $som_reg_path -Name "VersionMinor" -Value $version.Minor
        } 
        Write-Output "Updated Registry entry $som_reg_path"
    } else {
        # first time registering 
        New-Item -Path $som_reg_path 
        New-ItemProperty -Path $som_reg_path -Name "DisplayName" -Value $display_name -PropertyType "String"
        New-ItemProperty -Path $som_reg_path -Name "Version" -Value "$version" -PropertyType String      
        New-ItemProperty -Path $som_reg_path -Name "VersionMajor" -Value $version.Major -PropertyType DWord
        New-ItemProperty -Path $som_reg_path -Name "VersionMinor" -Value $version.Minor -PropertyType DWord     
        New-ItemProperty -Path $som_reg_path -Name "DisplayVersion" -Value "$version" -PropertyType String
        New-ItemProperty -Path $som_reg_path -Name "Publisher" -Value $publisher -PropertyType String
        New-ItemProperty -Path $som_reg_path -Name "NoModify" -Value 1 -PropertyType DWord
        New-ItemProperty -Path $som_reg_path -Name "NoRepair" -Value 1 -PropertyType DWord
        New-ItemProperty -Path $som_reg_path -Name "EstimatedSize" -Value $install_size -PropertyType DWord
        New-ItemProperty -Path $som_reg_path -Name "InstallLocation" -Value $install_folder -PropertyType String
        New-ItemProperty -Path $som_reg_path -Name "InstallDate" -Value (Get-Date -Format "yyyyMMdd") -PropertyType String
        New-ItemProperty -Path $som_reg_path -Name "UninstallString" -Value """$install_folder\uv\uv.exe"" run ""$install_folder\scripts\uninstall.py""" -PropertyType String
        New-ItemProperty -Path $som_reg_path -Name "Comments" -Value "$install_folder" -PropertyType String
        New-ItemProperty -Path $som_reg_path -Name "InstanceIndex" -Value $idx -PropertyType DWord
        New-ItemProperty -Path $som_reg_path -Name "DisplayIcon" -Value $install_folder"\assets\icon.ico" -PropertyType String     
        
        Write-Output "Created Registry entry $som_reg_path"

    }
}

function RemoveFromRegistry {
    $reg_path = FindRegistryEntry
    if ( $null -eq $reg_path){
        Write-Error("No registry entry found for SoM Lpr engine at location $install_folder")
        return
    }    
    if ($reg_path.Contains("HKEY_LOCAL_MACHINE"))   {
        EnsureElevated
    }
    Remove-Item -Path $reg_path
}

function GetRegisteredList {
    $result = @()
    foreach ( $root in @('Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
        'Registry::HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall')) {
        foreach ( $key in  @(Get-ChildItem -Path $root | Where-Object Name -match 'SOMLPR\b|SOMLPR\d+\b')) {
            try {
                $item = Get-ItemProperty -Path "Registry::$key"
                $result += "$($item.DisplayName) $($item.InstallLocation)"
            }  catch {
                $result += "ERROR ($key)"
            }
        }
    }
    return $result
}

# ############  Windows Service Handling  ##############

function FindMyServiceInstance {
    $svc_list =  Get-CimInstance -ClassName win32_service | Where-Object {$_.Name -match 'somlpr\b|somlpr\d+\b'} | Select-Object Name, DisplayName, PathName
    #return $svc_list[0]
    foreach ( $svc in $svc_list  ){
        $location = Split-Path -Path $svc.PathName -Parent
        if ( $location -eq $install_folder ) {
             return $svc
             }
    }
    return $null
}

function FindMaxInstalledServiceInstance {
    # return highest suffix index of installation service -1 = no service installed, 0 = somplr , X = somplrX 
    $svc_list =  Get-CimInstance -ClassName win32_service | Where-Object {$_.Name -match 'somlpr\b|somlpr\d+\b'} | Select-Object Name
    [int]$max_idx = -1
    # #$svc_list = @('SomLpr','SomLpr1', 'SomLpr2', 'SomLpr345')
    # $svc_list = @('SomLpr')
    foreach ( $svc in $svc_list  ){
        try { 
            if ( $svc.Name.Length -eq 6) 
            { 
                $idx = 0 
            }
            else { 
                $idx = [int]::Parse($svc.Name.SubString(6)) 
            }
            if ( $max_idx -lt $idx) {
                $max_idx = $idx
            }
        } catch { 
            continue
         }
    }
    return $max_idx
}

function AddAsService {
    # install as windows service 
    EnsureElevated
    $find_installed = FindMyServiceInstance 
    if ( $null -ne $find_installed) {
        Write-Error("somlpr service from $install_folder already installed as service $($find_installed.Name)")
        return
    }
    # find a name for the service (append number suffix to name if needed)
    $service_name = 'somlpr'
    $display_name = "SoM LPR Engine"
    $max_instance_idx = FindMaxInstalledServiceInstance
    if ( $max_instance_idx -gt -1 ) 
    { 
        $service_name = $service_name + ($max_instance_idx + 1)
        $display_name = $display_name + " #" + ($max_instance_idx + 1)
    } 
    # install as service
    $params = @{
        Name = $service_name
        BinaryPathName = "$install_folder\somlpr_svc.exe"
        DisplayName = $display_name
        StartupType = "Automatic"
        Description = "Society of Mind (SoM) License Plate Recognition engine."
      }
      try{
        New-Service @params
        Write-Output "Installed as service $service_name"
      } catch {
        Write-Error "Failed to install as service $service_name"
      }
}

function RemoveService
{
    # Remove from list of services
    EnsureElevated
    $find_installed = FindMyServiceInstance 
    if ( $null -eq $find_installed) {
        Write-Error("somlpr service from $install_folder is not installed as a windows service")
        return
    }
    $service_name = $find_installed.Name
    #stop service if
    if ( (Get-Service $service_name).Status -eq 'Running'){
        Stop-Service $service_name
    }
    # remove service ( try 3 methods depending on PS version and tools available on machine )
    try { (Get-WmiObject -Class Win32_Service -Filter "Name='$service_name'").Delete() }  
    catch { try { Remove-Service $service_name } 
    catch { try { Invoke-Expression "sc.exe delete $service_name" }
    catch { 
        Write-Error "Failed to remove service $service_name"
        return
    }}}
    Write-Output "Removed Service $service_name"
}

function GetServiceList {
    return Get-CimInstance -ClassName win32_service | Where-Object {$_.Name -match 'somlpr\b|somlpr\d+\b'} | Select-Object Name, State, StartMode
}

# netsh UrlACL Handling

function GetAclEveryoneUser {
  # get the user EveryOne as defined by local language 
  $everyone = ([wmi]"Win32_SID.SID='S-1-1-0'").AccountName
  return "\$everyone"
}

function CheckUrlAclExists([string]$protocol , [int]$port){
    # check if $protocol://*:$port is registered for ComputerName\Everyone via netst
    # returns $null if no entry found or the username that the reservation is on
    $output = netsh http show urlacl url="$($protocol)://*:$port/" 
    $user = $output -match '(?<=User:).*$' -replace 'User:' -replace ' ' -join '`n'
    if ( [bool]$user) { return $user }
    return $null
}
function AddUrlAclForEveyone([string]$protocol , [int]$port){
    EnsureElevated
    netsh.exe http add urlacl url="$($protocol)://*:$port/" user=$(GetAclEveryoneUser)
    $ok = $?
    if ($ok) {
        # add $protocol://*:$port reservation to .~urlacl file if not present ( will be read off and deleted during uninstall )
        $fp = "$PSScriptRoot\.~urlacl"
        if ( -not (Test-Path $fp -PathType Leaf)){
            $header = "#################################################################################`n" +
                      "#             Auto-Generated File on Windows . Do NOT delete / modify           #`n" +
                      "#                                                                               #`n" +
                      "#     - Contains url acl entries that were added by the SoM Lpr engine.         #`n" +
                      "#     - urls on list will be unregistered during the uninstall  procedure       #`n" +
                      "#################################################################################"

            Add-Content -Path $fp -Value $header
        }
        if ( -not (Select-String -Path $fp -Pattern "$($protocol)\://\*:$port/" -Quiet)) {
            Add-Content -Path $fp -Value "$($protocol)://*:$port/"
        }         
    }
    Write-Output "Add Url Acl $(if ($?) {'success'} else {'FAILED'}) ( $protocol)://*:$port/ )."
    return $ok
}

function RemoveUrlAcl([string]$protocol , [int]$port){
    EnsureElevated
    netsh.exe http delete urlacl url="$($protocol)://*:$port/" 
    $ok = $?
    Write-Output "Remove Url Acl $(if ($?) {'success'} else {'FAILED'})  ( $protocol)://*:$port/ )."
    return $ok
}

function PurgeUrlAcls {
    EnsureElevated
    # read all lines from .~urlacl and remove reservations via netsh  ( used during uninstall 0)
    $fp = "$PSScriptRoot\.~urlacl"
    if (-not (Test-Path $fp -PathType Leaf)) { return }
    Get-Content $fp | ForEach-Object {
        $tokens = @($_ -split ':')
        if ( $tokens.Length -ne 3) { return }
        $protocol  = $tokens[0]
        $port = [int]($tokens[2] -split '/')[0]
        if ( $(GetAclEveryoneUser) -eq  $(CheckUrlAclExists $protocol $port) ) {
            #  there is an \Everyone reservation 
            $null = RemoveUrlAcl $protocol $port 
        } else {
            Write-Output "$($protocol)://*:$port/ already unregistered"
        }
    }
}


# ############  Script Entry Point  ##############


if ($Help) {
    Get-Help $PSCommandPath -Detailed
    Exit 2
  }

# check minimal PowerShell Version ( 5.1 )
if ( ($PSVersionTable.PSVersion.Major -lt 5) -or (( $PSVersionTable.PSVersion.Major -eq 5) -and ($PSVersionTable.PSVersion.Minor -lt 1 ))){
	$major = $PSVersionTable.PSVersion.Major
	$minor = $PSVersionTable.PSVersion.Minor
	Write-Error "Minimum supported PowerShell version is 5.1"
	Write-Output "current PowerShell version is $major.$minor. Please update to 5.1 minumum."
	Exit 2 
}


if ( $Service.Length -gt 0) {
    # Self-elevate the script if we manipulate Services
    EnsureElevated
}

if ($Machine) {
    # Self-elevate the script if we write to HKLM
    EnsureElevated
    $reg_uninstall = 'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
} else {
    $reg_uninstall = 'Registry::HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
}

# Add / Remove Registry Entries 
if ( $Registry.Length -gt 0){
    if ( $Registry[0] -in @('Add','add','a', 'i')) {
        AddToRegistry
    }
    if ( $Registry[0] -in @('Remove','remove','r', 'u')) {
        RemoveFromRegistry
    }
}
# Add / Remove Service Entries 
if ( $Service.Length -gt 0){
    if ( $Service[0] -in @('Add','add','a', 'i')) {
        AddAsService
    }
    if ( $Service[0] -in @('Remove','remove','r', 'u')) {
        RemoveService
    }
}
# Do something to Url Acl list
if ( $UrlAcl.Length -gt 0){
    if ( $UrlAcl[0] -in @('Purge'))
    {
        PurgeUrlAcls
        Exit 0
    }
    if ( $Port -eq $null){
        Write-Error ("-Port must be specified")
        Exit 3
    }
    $protocol = if ($Https) {'https'} else {'http'} 
    switch ($UrlAcl[0]) {

        "Check" {
            return ( [bool]$(CheckUrlAclExists $protocol $port))
        }

        "Add" {
            if ( $(CheckUrlAclExists $protocol $port)){
                Write-Output("Url $($protocol)://*:$port/ already registered in url acl." )
                Exit 4
            }
            return $(AddUrlAclForEveyone $protocol $port)
        }
        
        "Remove" {
            if ( -not ( $(CheckUrlAclExists $protocol $port))){
                Write-Output("Url $($protocol)://*:$port/ is not in url acl." )
                Exit 4
            }
            return $(RemoveUrlAcl $protocol $port)
        }
        Default { }
  }
}

# Show list & status if no other action specified 
if ($Service.Length -eq 0 -and $Registry.Length -eq 0 -and $UrlAcl.Length -eq 0 ){
    Write-Output "Windows Service/App (Un)Installer for SoM LPR`n"
    Write-Output "Registered Instances of Engine:`n"
    Write-Output(GetRegisteredList)
    Write-Output "`nRegistered Windows Services:`n"
    Write-Output(GetServiceList)
    Write-Output("`n`n")
    Write-Output("Type win64.ps1 -Help for help on this script../win")

} else {
    Write-Output 'done.'
}

Exit 0
