# cython: language_level=3

from dataclasses import dataclass, field
from typing import Any, List, Tuple
import cv2
import numpy as np
from numpy import ndarray, dtype, floating
import classes
import time
"""  Ai detection preprocessing and postprocessing of images and tensors. ML boilerplate goes here """

__author__ = "Jakub Marczewski "
__copyright__ = "Copyright 2024, Jakub Marczewski"


class PlatoProcessing:
    score_thr = 0.65
    nms_thr = 0.45

    @classmethod
    def preprocess(cls, img: np.ndarray, input_size=(416, 416), swap=(2, 0, 1)) -> tuple[np.ndarray, float]:
        if len(img.shape) == 3:
            padded_img = np.ones((input_size[0], input_size[1], 3), dtype=np.uint8) * 114
        else:
            padded_img = np.ones(input_size, dtype=np.uint8) * 114

        r = min(input_size[0] / img.shape[0], input_size[1] / img.shape[1])
        resized_img = cv2.resize(
            img,
            (int(img.shape[1] * r), int(img.shape[0] * r)),
            interpolation=cv2.INTER_LINEAR,
        ).astype(np.uint8)
        padded_img[: int(img.shape[0] * r), : int(img.shape[1] * r)] = resized_img

        padded_img = padded_img.transpose(swap)
        padded_img = np.ascontiguousarray(padded_img, dtype=np.float32)
        padded_img = np.expand_dims(padded_img, 0)
        return padded_img, r

    @classmethod
    def postprocess(cls, outputs, ratio: float):
        outputs = cls._postprocess(outputs, (416, 416))[0]
        results = cls.get_detections(outputs, ratio)
        return results

    @classmethod
    def _postprocess(cls, outputs, img_size: Tuple, p6=False):
        """ post process detections """
        grids = []
        expanded_strides = []
        strides = [8, 16, 32] if not p6 else [8, 16, 32, 64]

        hsizes = [img_size[0] // stride for stride in strides]
        wsizes = [img_size[1] // stride for stride in strides]

        for hsize, wsize, stride in zip(hsizes, wsizes, strides):
            xv, yv = np.meshgrid(np.arange(wsize), np.arange(hsize))
            grid = np.stack((xv, yv), 2).reshape(1, -1, 2)
            grids.append(grid)
            shape = grid.shape[:2]
            expanded_strides.append(np.full((*shape, 1), stride))

        grids = np.concatenate(grids, 1)
        expanded_strides = np.concatenate(expanded_strides, 1)
        outputs[..., :2] = (outputs[..., :2] + grids) * expanded_strides
        outputs[..., 2:4] = np.exp(outputs[..., 2:4]) * expanded_strides

        return outputs

    @classmethod
    def get_detections(cls, tensor_output: np.ndarray, ratio: float):
        boxes = tensor_output[:, :4]
        scores = tensor_output[:, 4:5] * tensor_output[:, 5:]
        boxes_xyxy = np.ones_like(boxes)
        boxes_xyxy[:, 0] = boxes[:, 0] - boxes[:, 2] / 2.
        boxes_xyxy[:, 1] = boxes[:, 1] - boxes[:, 3] / 2.
        boxes_xyxy[:, 2] = boxes[:, 0] + boxes[:, 2] / 2.
        boxes_xyxy[:, 3] = boxes[:, 1] + boxes[:, 3] / 2.
        boxes_xyxy /= ratio
        detections = cls.multiclass_nms_class_agnostic(boxes_xyxy, scores, nms_thr=cls.nms_thr, score_thr=cls.score_thr)
        return detections

    @classmethod
    def nms(cls, boxes, scores, nms_thr):
        """Single class NMS implemented in Numpy."""
        x1 = boxes[:, 0]
        y1 = boxes[:, 1]
        x2 = boxes[:, 2]
        y2 = boxes[:, 3]

        areas = (x2 - x1 + 1) * (y2 - y1 + 1)
        order = scores.argsort()[::-1]

        keep = []
        while order.size > 0:
            i = order[0]
            keep.append(i)
            xx1 = np.maximum(x1[i], x1[order[1:]])
            yy1 = np.maximum(y1[i], y1[order[1:]])
            xx2 = np.minimum(x2[i], x2[order[1:]])
            yy2 = np.minimum(y2[i], y2[order[1:]])

            w = np.maximum(0.0, xx2 - xx1 + 1)
            h = np.maximum(0.0, yy2 - yy1 + 1)
            inter = w * h
            ovr = inter / (areas[i] + areas[order[1:]] - inter)

            inds = np.where(ovr <= nms_thr)[0]
            order = order[inds + 1]

        return keep

    @classmethod
    def multiclass_nms_class_agnostic(cls, boxes, scores, nms_thr, score_thr):
        """Multiclass NMS implemented in Numpy. Class-agnostic version."""
        cls_inds = scores.argmax(1)
        cls_scores = scores[np.arange(len(cls_inds)), cls_inds]

        valid_score_mask = cls_scores > score_thr
        if valid_score_mask.sum() == 0:
            return None
        valid_scores = cls_scores[valid_score_mask]
        valid_boxes = boxes[valid_score_mask]
        valid_cls_inds = cls_inds[valid_score_mask]
        keep = PlatoProcessing.nms(valid_boxes, valid_scores, nms_thr)
        if keep:
            dets = np.concatenate(
                [valid_boxes[keep], valid_scores[keep, None], valid_cls_inds[keep, None]], 1
            )
        return dets


class SimbaProcessing:
    score_thr = 0.65
    nms_thr = 0.45

    @dataclass
    class SimbaInferInfo:
        ratios: list[float] = field(default_factory=list)

    # @classmethod
    # def preprocess(cls, im: np.ndarray, input_size=(96, 384), swap=(2, 0, 1)) -> tuple[
    #     ndarray[Any, dtype[floating[Any]]], float]:
    #     if len(im.shape) == 3:
    #         padded_img = np.ones((input_size[0], input_size[1], 3), dtype=np.uint8) * 114
    #     else:
    #         padded_img = np.ones(input_size, dtype=np.uint8) * 114
    #
    #     r = min(input_size[0] / im.shape[0], input_size[1] / im.shape[1])
    #     resized_img = cv2.resize(
    #         im,
    #         (int(im.shape[1] * r), int(im.shape[0] * r)),
    #         interpolation=cv2.INTER_LINEAR,
    #     ).astype(np.uint8)
    #     padded_img[: int(im.shape[0] * r), : int(im.shape[1] * r)] = resized_img
    #
    #     padded_img = padded_img.transpose(swap)
    #     padded_img = np.ascontiguousarray(padded_img, dtype=np.float32)
    #     return padded_img, r

    @classmethod
    def preprocess(cls, imgs: list[np.ndarray], input_size=(96, 384), swap=(2, 0, 1)) -> \
            tuple[ndarray[Any, dtype[floating[Any]]], SimbaInferInfo]:
        input_tensor = np.ndarray((len(imgs), 3, 96, 384), np.float32)
        ratios = []
        for i, im in enumerate(imgs):
            if len(im.shape) == 3:
                padded_img = np.ones((input_size[0], input_size[1], 3), dtype=np.uint8) * 114
            else:
                padded_img = np.ones(input_size, dtype=np.uint8) * 114

            ratio = min(input_size[0] / im.shape[0], input_size[1] / im.shape[1])
            ratios.append(ratio)
            resized_img = cv2.resize(
                im,
                (int(im.shape[1] * ratio), int(im.shape[0] * ratio)),
                interpolation=cv2.INTER_LINEAR,
            ).astype(np.uint8)
            padded_img[: int(im.shape[0] * ratio), : int(im.shape[1] * ratio)] = resized_img
            padded_img = padded_img.transpose(swap)
            padded_img = np.ascontiguousarray(padded_img, dtype=np.float32)
            padded_img = np.expand_dims(padded_img, axis=0)
            input_tensor[i] = padded_img
        return input_tensor, cls.SimbaInferInfo(ratios=ratios)


    @classmethod
    def __postprocess(cls, output: np.ndarray, extras: SimbaInferInfo, **kwargs) -> np.ndarray:
        """ process ai output of symbols from multiple plate images cut up into detections
            result  0-4 = box  5 = confidence, 6 = class  7 = plate image index
        """


        ts = time.perf_counter()
        results = np.zeros((60, 7))
        offsets = [item for row in extras.offsets for item in row]
        img_idx = [i for i in range(len(extras.offsets)) for _ in range(len(extras.offsets[i]))]
        k_idx = 0
        det_idx = 0
        for s, o in enumerate(extras.offsets):
            cache = np.zeros((20, 6))  # assume max 20 ext detections per plate. increase if needed
            cache_idx = 0
            im_output = output[k_idx:k_idx + len(o)]
            k_idx += len(o)
            for k in range(len(o)):
                p = im_output[k:k + 1]
                predictions = cls._postprocess(p, (128, 128))[0]
                boxes = predictions[:, :4]
                scores = predictions[:, 4:5] * predictions[:, 5:]
                boxes_xyxy = np.ones_like(boxes)
                boxes_xyxy[:, 0] = boxes[:, 0] - boxes[:, 2] / 2.
                boxes_xyxy[:, 1] = boxes[:, 1] - boxes[:, 3] / 2.
                boxes_xyxy[:, 2] = boxes[:, 0] + boxes[:, 2] / 2.
                boxes_xyxy[:, 3] = boxes[:, 1] + boxes[:, 3] / 2.
                # dets = self.multiclass_nms(boxes_xyxy, scores, nms_thr=0.45, score_thr=0.2)
                dets = cls.multiclass_nms_class_agnostic(boxes_xyxy, scores, nms_thr=cls.nms_thr,
                                                         score_thr=cls.score_thr)
                if dets is None:
                    continue  # no detections on this image part
                ratio = extras.ratios[img_idx[k]]
                number_of_detects = dets.shape[0]
                offset = offsets[k] * ratio
                for i in range(number_of_detects):
                    # translate 128x128 partial image coordinated into original image coordinates
                    box = dets[i, :4]
                    x1 = offset + box[0] * ratio
                    y1 = box[1] * ratio
                    x2 = offset + box[2] * ratio
                    y2 = box[3] * ratio
                    cache[cache_idx] = [x1, y1, x2, y2, dets[i][4], dets[i][5]]
                    cache_idx += 1
            im_results = cache[0:cache_idx, 0:6]
            im_results = cls._nms_multipart_detects(im_results)
            for j in range(im_results.shape[0]):
                results[det_idx, 6] = s
                results[det_idx, 0:6] = im_results[j]
                det_idx += 1
        results = results[0:det_idx, 0:7]
        duration = round(time.perf_counter() - ts, 3)
        # print(f'Meili post-process took {duration} sec.')
        ''' result  0-4 = box  5 = confidence, 6 = class  7 = plate image index'''
        return results

    @classmethod
    def postprocess(cls, outputs, extras: SimbaInferInfo):
        results = []
        for i in range(outputs.shape[0]):
            output = outputs[i]
            output = cls._postprocess(output)
            boxes = output[:, :4]
            scores = output[:, 4:5] * output[:, 5:]
            boxes_xyxy = np.ones_like(boxes)
            boxes_xyxy[:, 0] = boxes[:, 0] - boxes[:, 2] / 2.
            boxes_xyxy[:, 1] = boxes[:, 1] - boxes[:, 3] / 2.
            boxes_xyxy[:, 2] = boxes[:, 0] + boxes[:, 2] / 2.
            boxes_xyxy[:, 3] = boxes[:, 1] + boxes[:, 3] / 2.
            boxes_xyxy /= extras.ratios[i]
            detections = cls.multiclass_nms_class_agnostic(boxes_xyxy, scores, nms_thr=cls.nms_thr,
                                                           score_thr=cls.score_thr)
            results.append(detections)

        return results


    @classmethod
    def _postprocess(cls, outputs, img_size=(96, 384), p6=False):
        """ post process detections """
        grids = []
        expanded_strides = []
        strides = [8, 16, 32] if not p6 else [8, 16, 32, 64]

        hsizes = [img_size[0] // stride for stride in strides]
        wsizes = [img_size[1] // stride for stride in strides]

        for hsize, wsize, stride in zip(hsizes, wsizes, strides):
            xv, yv = np.meshgrid(np.arange(wsize), np.arange(hsize))
            grid = np.stack((xv, yv), 2).reshape(1, -1, 2)
            grids.append(grid)
            shape = grid.shape[:2]
            expanded_strides.append(np.full((*shape, 1), stride))

        grids = np.concatenate(grids, 1)
        expanded_strides = np.concatenate(expanded_strides, 1)
        outputs[..., :2] = (outputs[..., :2] + grids) * expanded_strides
        outputs[..., 2:4] = np.exp(outputs[..., 2:4]) * expanded_strides
        return outputs




    # @classmethod
    # def postprocess(cls, outputs, img_size, p6=False):
    #     """ post process detections """
    #     grids = []
    #     expanded_strides = []
    #     strides = [8, 16, 32] if not p6 else [8, 16, 32, 64]
    #
    #     hsizes = [img_size[0] // stride for stride in strides]
    #     wsizes = [img_size[1] // stride for stride in strides]
    #
    #     for hsize, wsize, stride in zip(hsizes, wsizes, strides):
    #         xv, yv = np.meshgrid(np.arange(wsize), np.arange(hsize))
    #         grid = np.stack((xv, yv), 2).reshape(1, -1, 2)
    #         grids.append(grid)
    #         shape = grid.shape[:2]
    #         expanded_strides.append(np.full((*shape, 1), stride))
    #
    #     grids = np.concatenate(grids, 1)
    #     expanded_strides = np.concatenate(expanded_strides, 1)
    #     outputs[..., :2] = (outputs[..., :2] + grids) * expanded_strides
    #     outputs[..., 2:4] = np.exp(outputs[..., 2:4]) * expanded_strides
    #
    #     return outputs

    @classmethod
    def get_detections(cls, output_tensor: np.ndarray, ratio: float) -> np.ndarray:

        boxes = output_tensor[:, :4]
        scores = output_tensor[:, 4:5] * output_tensor[:, 5:]
        boxes_xyxy = np.ones_like(boxes)
        boxes_xyxy[:, 0] = boxes[:, 0] - boxes[:, 2] / 2.
        boxes_xyxy[:, 1] = boxes[:, 1] - boxes[:, 3] / 2.
        boxes_xyxy[:, 2] = boxes[:, 0] + boxes[:, 2] / 2.
        boxes_xyxy[:, 3] = boxes[:, 1] + boxes[:, 3] / 2.
        boxes_xyxy /= ratio
        detections = cls.multiclass_nms_class_agnostic(boxes_xyxy, scores, nms_thr=cls.nms_thr, score_thr=cls.score_thr)
        return detections

    @classmethod
    def nms(cls, boxes, scores, nms_thr):
        """Single class NMS implemented in Numpy."""
        x1 = boxes[:, 0]
        y1 = boxes[:, 1]
        x2 = boxes[:, 2]
        y2 = boxes[:, 3]

        areas = (x2 - x1 + 1) * (y2 - y1 + 1)
        order = scores.argsort()[::-1]

        keep = []
        while order.size > 0:
            i = order[0]
            keep.append(i)
            xx1 = np.maximum(x1[i], x1[order[1:]])
            yy1 = np.maximum(y1[i], y1[order[1:]])
            xx2 = np.minimum(x2[i], x2[order[1:]])
            yy2 = np.minimum(y2[i], y2[order[1:]])

            w = np.maximum(0.0, xx2 - xx1 + 1)
            h = np.maximum(0.0, yy2 - yy1 + 1)
            inter = w * h
            ovr = inter / (areas[i] + areas[order[1:]] - inter)

            inds = np.where(ovr <= nms_thr)[0]
            order = order[inds + 1]

        return keep

    @classmethod
    def multiclass_nms_class_agnostic(cls, boxes, scores, nms_thr, score_thr):
        """Multiclass NMS implemented in Numpy. Class-agnostic version."""
        cls_inds = scores.argmax(1)
        cls_scores = scores[np.arange(len(cls_inds)), cls_inds]

        valid_score_mask = cls_scores > score_thr
        if valid_score_mask.sum() == 0:
            return None
        valid_scores = cls_scores[valid_score_mask]
        valid_boxes = boxes[valid_score_mask]
        valid_cls_inds = cls_inds[valid_score_mask]
        keep = SimbaProcessing.nms(valid_boxes, valid_scores, nms_thr)
        if keep:
            dets = np.concatenate(
                [valid_boxes[keep], valid_scores[keep, None], valid_cls_inds[keep, None]], 1
            )
        return dets


class JohnyProcessing:

    # original pytorch transformations
    # transformations = transforms.Compose([
    #     transforms.Resize((96, 64)),
    #     transforms.Grayscale(num_output_channels=1),
    #     transforms.ToTensor(),
    #     transforms.Normalize([0.5], [0.5])
    # ])

    @classmethod
    def resize_aspect_with_pad(cls, im: np.ndarray, width: int, height: int, padding_color: Any = (0, 0, 0)) \
            -> np.ndarray:
        """
        resizes image maintaining aspect ratio by adding needed padding ( mainly to the shorter side of the image )
        :param im: any image format ( color, grayscale )
        :param width: desired width
        :param height: desired height
        :param padding_color: color to use for padding ( black is default )
        :return: the resized image
        """
        orig_w = im.shape[1]
        orig_h = im.shape[0]
        if orig_w == width and orig_h == height:
            return im
        # fit width
        rw = width / float(orig_w)
        new_w = int(rw * orig_w)
        new_h = int(rw * orig_h)
        if new_h > height:
            # resize again by height if needed
            orig_w = new_w
            orig_h = new_h
            rh = height / float(orig_h)
            new_w = int(rh * orig_w)
            new_h = int(rh * orig_h)
        # resize
        resized = cv2.resize(im, (new_w, new_h))
        # pad
        delta_w = width - resized.shape[1]
        delta_h = height - resized.shape[0]
        top, bottom = delta_h // 2, delta_h - (delta_h // 2)
        left, right = delta_w // 2, delta_w - (delta_w // 2)
        new_im = cv2.copyMakeBorder(resized, top, bottom, left, right, cv2.BORDER_CONSTANT,
                                    value=padding_color)
        return new_im

    @classmethod
    def transform_image(cls, im: np.ndarray) -> np.ndarray:  # noqa
        try:
            if im.shape[2] == 3:
                im = cv2.cvtColor(im.astype('uint8'), cv2.COLOR_BGR2GRAY)
        except IndexError:
            pass
        im = cls.resize_aspect_with_pad(im, width=64, height=96, padding_color=128)
        im = im.astype(np.float32)
        # Normalise to values between [-1,1]
        im = 2. * (im - np.min(im)) / np.ptp(im) - 1
        return im

    @classmethod
    def preprocess(cls, imgs: list[np.ndarray]):
        input_tensor = np.ndarray((len(imgs), 1, 96, 64), np.float32)
        for i in range(len(imgs)):
            im = cls.transform_image(imgs[i])
            im = np.expand_dims(im, axis=0)
            input_tensor[i] = im
        return input_tensor

    @classmethod
    def softmax(cls, x):  # noqa
        """Compute softmax values for each sets of scores in x."""
        return np.exp(x - np.max(x)) / np.exp(x - np.max(x)).sum()

    @classmethod
    def postprocess_result(cls, output_tensor: np.ndarray) -> list[list[tuple[Any, Any]]]:
        results = []
        for i in range(output_tensor.shape[0]):
            row = output_tensor[i:i + 1]
            # softmax to get percent of certainty
            probabilities = cls.softmax(row)
            a = np.argsort(probabilities)
            top3 = [a[0][-1], a[0][-2], a[0][-3]]
            # print (top3)
            d = []
            for j in top3:
                t = classes.JOHNY[j], round(100 * probabilities[0][j], 2)
                d.append(t)
            results.append(d)
            # s = '{0:.10f}'.format(round(probabilities[0][i], 4))
            # print(f'{SR1_JohnyLetter.REV_CLASS_MAP[i]}({i}) = {s}')
        return results


class MeiliProcessing:
    @dataclass
    class MeiliInferInfo:
        offsets: list[list[int]] = field(default_factory=list)
        ratios: list[float] = 0.0

    score_thr = 0.65
    nms_thr = 0.45

    @classmethod
    def preprocess(cls, imgs: list[np.ndarray]) -> tuple[np.ndarray, MeiliInferInfo]:
        """ make image 128 height compatible sub-images of ext-probable parts of the plate ( left, right, 1/3, etc ... )
            Output is onnx ort_inputs ready - ie. image is transposed to (3, 128, 128)  etc.
        """
        im_cutouts = []
        offsets = []
        ratios = []
        for i, im in enumerate(imgs):
            ratios.append(im.shape[0] / 128)
            im_wrk = cls.image_resize_with_aspect_ratio(im, height=128)  # maintains aspect ratio
            if im_wrk.shape[1] < 128:
                # r-padd very narrow width to a 128 minimum
                tmp = np.zeros((128, 128, 3))
                tmp[0:128, 0:im_wrk.shape[1]] = im_wrk
                im_wrk = tmp.copy()
            x_times = int(im_wrk.shape[1] / 128)  # how many full 128 segments fit into image
            w = im_wrk.shape[1]  # width after resize
            im_offsets = []
            swap = (2, 0, 1)
            if x_times >= 0:
                # append left-most
                im_offsets.append(0)
                im_cutouts.append(np.ascontiguousarray(im_wrk[0:128, 0:128].copy().transpose(swap), dtype=np.float32))
            if x_times >= 1:
                # append right-most
                im_offsets.append(w - 128)
                im_cutouts.append(
                    np.ascontiguousarray(im_wrk[0:128, w - 128:w].copy().transpose(swap), dtype=np.float32))
            if x_times >= 2:
                # append left-common emblem
                im_offsets.append(64)
                im_cutouts.append(np.ascontiguousarray(im_wrk[0:128, 64:192].copy().transpose(swap), dtype=np.float32))
            elif x_times >= 3:
                # append right-common emblem
                im_offsets.append(w - 256)
                im_cutouts.append(
                    np.ascontiguousarray(im_wrk[0:128, w - 256:w - 128].copy().transpose(swap), dtype=np.float32))
            elif x_times >= 4:
                # append middle
                im_offsets.append(int(w / 2) - 64)
                im_cutouts.append(
                    np.ascontiguousarray(im_wrk[0:128, int(w / 2) - 64:int(w / 2) + 64].copy().transpose(swap),
                                         dtype=np.float32))
            offsets.append(im_offsets)
        input_tensor = np.stack(im_cutouts)
        return input_tensor, cls.MeiliInferInfo(offsets=offsets, ratios=ratios)

    @classmethod
    def postprocess(cls, output: np.ndarray, extras: MeiliInferInfo, **kwargs) -> np.ndarray:
        """ process ai output from multiple plate images cut up into detections
            result  0-4 = box  5 = confidence, 6 = class  7 = plate image index
        """
        ts = time.perf_counter()
        results = np.zeros((60, 7))
        offsets = [item for row in extras.offsets for item in row]
        img_idx = [i for i in range(len(extras.offsets)) for _ in range(len(extras.offsets[i]))]
        k_idx = 0
        det_idx = 0
        for s, o in enumerate(extras.offsets):
            cache = np.zeros((20, 6))  # assume max 20 ext detections per plate. increase if needed
            cache_idx = 0
            im_output = output[k_idx:k_idx + len(o)]
            k_idx += len(o)
            for k in range(len(o)):
                p = im_output[k:k + 1]
                predictions = cls._postprocess(p, (128, 128))[0]
                boxes = predictions[:, :4]
                scores = predictions[:, 4:5] * predictions[:, 5:]
                boxes_xyxy = np.ones_like(boxes)
                boxes_xyxy[:, 0] = boxes[:, 0] - boxes[:, 2] / 2.
                boxes_xyxy[:, 1] = boxes[:, 1] - boxes[:, 3] / 2.
                boxes_xyxy[:, 2] = boxes[:, 0] + boxes[:, 2] / 2.
                boxes_xyxy[:, 3] = boxes[:, 1] + boxes[:, 3] / 2.
                # dets = self.multiclass_nms(boxes_xyxy, scores, nms_thr=0.45, score_thr=0.2)
                dets = cls.multiclass_nms_class_agnostic(boxes_xyxy, scores, nms_thr=cls.nms_thr,
                                                         score_thr=cls.score_thr)
                if dets is None:
                    continue  # no detections on this image part
                ratio = extras.ratios[img_idx[k]]
                number_of_detects = dets.shape[0]
                offset = offsets[k] * ratio
                for i in range(number_of_detects):
                    # translate 128x128 partial image coordinated into original image coordinates
                    box = dets[i, :4]
                    x1 = offset + box[0] * ratio
                    y1 = box[1] * ratio
                    x2 = offset + box[2] * ratio
                    y2 = box[3] * ratio
                    cache[cache_idx] = [x1, y1, x2, y2, dets[i][4], dets[i][5]]
                    cache_idx += 1
            im_results = cache[0:cache_idx, 0:6]
            im_results = cls._nms_multipart_detects(im_results)
            for j in range(im_results.shape[0]):
                results[det_idx, 6] = s
                results[det_idx, 0:6] = im_results[j]
                det_idx += 1
        results = results[0:det_idx, 0:7]
        duration = round(time.perf_counter() - ts, 3)
        # print(f'Meili post-process took {duration} sec.')
        ''' result  0-4 = box  5 = confidence, 6 = class  7 = plate image index'''
        return results

    @classmethod
    def _nms_multipart_detects(cls, dets: np.ndarray) -> np.ndarray:  # noqa
        """
            combine overlapping detections from multiple partial images
            score is taken as max(). duration is negligible ( 0.00 )
        """
        # ts = time.time()
        result = np.ndarray(dets.shape)
        result_cnt = 0
        for i in range(dets.shape[0]):
            cls_idx = dets[i][5]
            if cls_idx == -1:
                continue
            x1 = dets[i][0]
            y1 = dets[i][1]
            x2 = dets[i][2]
            y2 = dets[i][3]
            conf = dets[i][4]
            for j in range(i + 1, dets.shape[0]):
                cls_comp = dets[j][5]
                if cls_comp != cls_idx:
                    continue
                # check amount of overlap between detections
                xa1 = dets[i][0]
                ya1 = dets[i][1]
                xa2 = dets[i][2]
                ya2 = dets[i][3]
                xb1 = dets[j][0]
                yb1 = dets[j][1]
                xb2 = dets[j][2]
                yb2 = dets[j][3]
                si = max(0, min(xa2, xb2) - max(xa1, xb1)) * max(0, min(ya2, yb2) - max(ya1, yb1))  # intersection area
                sa = (xa2 - xa1) * (ya2 - ya1)  # area of dets[i]
                sb = (xb2 - xb1) * (yb2 - yb1)  # area of dets[j]
                s = sa + sb - si  # area outside intersection
                ratio = si / s  # ratio of intersection to non-intersection ( 0.0 - 1.0 )
                # print(f"{i} and {j} are same detection ({CLASS_NAMES[int(dets[i][5])]})")
                # print(f'({i}):({int(xa1)},{int(ya1)}), ({int(xa2)}, {int(ya2)})')
                # print(f'({j}):({int(xb1)},{int(yb1)}), ({int(xb2)}, {int(yb2)})')
                # print(f'ratio of intersection/non-intersection of {i} & {j} = {ratio}')
                if ratio > 0.33:  # 1/3 or more intersect
                    x1 = min(xa1, xb1)
                    y1 = min(ya1, yb1)
                    x2 = max(xb2, xb2)
                    y2 = min(yb2, yb2)
                    conf = max(dets[i][4], dets[j][4])
                dets[j][5] = -1
                pass
            result[result_cnt] = [x1, y1, x2, y2, conf, dets[i][5]]
            result_cnt += 1
        result = result[:result_cnt]  # crop result ndarray
        # duration = round(time.time() - ts, 3)
        # print(f'batch nms consolidated {dets.shape[0] - result_cnt} in {duration}s.')
        return result

    @classmethod
    def nms(cls, boxes, scores, nms_thr):
        """Single class NMS implemented in Numpy."""
        x1 = boxes[:, 0]
        y1 = boxes[:, 1]
        x2 = boxes[:, 2]
        y2 = boxes[:, 3]

        areas = (x2 - x1 + 1) * (y2 - y1 + 1)
        order = scores.argsort()[::-1]

        keep = []
        while order.size > 0:
            i = order[0]
            keep.append(i)
            xx1 = np.maximum(x1[i], x1[order[1:]])
            yy1 = np.maximum(y1[i], y1[order[1:]])
            xx2 = np.minimum(x2[i], x2[order[1:]])
            yy2 = np.minimum(y2[i], y2[order[1:]])

            w = np.maximum(0.0, xx2 - xx1 + 1)
            h = np.maximum(0.0, yy2 - yy1 + 1)
            inter = w * h
            ovr = inter / (areas[i] + areas[order[1:]] - inter)

            inds = np.where(ovr <= nms_thr)[0]
            order = order[inds + 1]

        return keep

    @classmethod
    def multiclass_nms_class_agnostic(cls, boxes, scores, nms_thr, score_thr) -> np.ndarray | None:
        """Multiclass NMS implemented in Numpy. Class-agnostic version."""
        cls_inds = scores.argmax(1)
        cls_scores = scores[np.arange(len(cls_inds)), cls_inds]

        valid_score_mask = cls_scores > score_thr
        if valid_score_mask.sum() == 0:
            return None
        valid_scores = cls_scores[valid_score_mask]
        valid_boxes = boxes[valid_score_mask]
        valid_cls_inds = cls_inds[valid_score_mask]
        keep = cls.nms(valid_boxes, valid_scores, nms_thr)
        if keep:
            keep = np.concatenate(
                [valid_boxes[keep], valid_scores[keep, None], valid_cls_inds[keep, None]], 1
            )
        return keep

    @classmethod
    def image_resize_with_aspect_ratio(cls, image, width=None, height=None, inter=cv2.INTER_AREA):  # noqa
        """ Resize with aspect ratio"""
        # initialize the dimensions of the image to be resized and
        # grab the image size
        dim = None
        (h, w) = image.shape[:2]

        # if both the width and height are None, then return the
        # original image
        if width is None and height is None:
            return image

        # check to see if the width is None
        if width is None:
            # calculate the ratio of the height and construct the
            # dimensions
            r = height / float(h)
            dim = (int(w * r), height)

        # otherwise, the height is None
        else:
            # calculate the ratio of the width and construct the
            # dimensions
            r = width / float(w)
            dim = (width, int(h * r))

        # resize the image
        resized = cv2.resize(image, dim, interpolation=inter)

        # return the resized image
        return resized

    @classmethod
    def _postprocess(cls, outputs, img_size, p6=False):  # noqa
        """ post process detections """
        grids = []
        expanded_strides = []
        strides = [8, 16, 32] if not p6 else [8, 16, 32, 64]

        hsizes = [img_size[0] // stride for stride in strides]
        wsizes = [img_size[1] // stride for stride in strides]

        for hsize, wsize, stride in zip(hsizes, wsizes, strides):
            xv, yv = np.meshgrid(np.arange(wsize), np.arange(hsize))
            grid = np.stack((xv, yv), 2).reshape(1, -1, 2)
            grids.append(grid)
            shape = grid.shape[:2]
            expanded_strides.append(np.full((*shape, 1), stride))

        grids = np.concatenate(grids, 1)
        expanded_strides = np.concatenate(expanded_strides, 1)
        outputs[..., :2] = (outputs[..., :2] + grids) * expanded_strides
        outputs[..., 2:4] = np.exp(outputs[..., 2:4]) * expanded_strides

        return outputs


class EndeisProcessing:

    @classmethod
    def transform_image(cls, im: np.ndarray) -> np.ndarray:  # noqa
        im = cls.resize_aspect_with_pad(im, width=128, height=96)
        im = im.astype(np.float32)
        # add a dimension and transpose to (1, 3, 96, 128)
        im = np.expand_dims(im, 0)
        im = np.transpose(im, (0, 3, 1, 2))

        # normalize to training dataset mean/std
        mean = [0.211, 0.227, 0.253]
        std = [0.276, 0.280, 0.304]
        for i in range(3):
            im[:, :, :, i] = (im[:, :, :, i] - mean[i]) / std[i]
            im[:, :, :, i] = (im[:, :, :, i] - mean[i]) / std[i]
        return im

    @classmethod
    def resize_aspect_with_pad(cls, im: np.ndarray, width: int, height: int, padding_color: Any = (0, 0, 0)) \
            -> np.ndarray:
        """
        resizes image maintaining aspect ratio by adding needed padding ( mainly to the shorter side of the image )
        :param im: any image format ( color, grayscale )
        :param width: desired width
        :param height: desired height
        :param padding_color: color to use for padding ( black is default )
        :return: the resized image
        """
        orig_w = im.shape[1]
        orig_h = im.shape[0]
        if orig_w == width and orig_h == height:
            return im
        # fit width
        rw = width / float(orig_w)
        new_w = int(rw * orig_w)
        new_h = int(rw * orig_h)
        if new_h > height:
            # resize again by height if needed
            orig_w = new_w
            orig_h = new_h
            rh = height / float(orig_h)
            new_w = int(rh * orig_w)
            new_h = int(rh * orig_h)
        # resize
        resized = cv2.resize(im, (new_w, new_h))
        # pad
        delta_w = width - resized.shape[1]
        delta_h = height - resized.shape[0]
        top, bottom = delta_h // 2, delta_h - (delta_h // 2)
        left, right = delta_w // 2, delta_w - (delta_w // 2)
        new_im = cv2.copyMakeBorder(resized, top, bottom, left, right, cv2.BORDER_CONSTANT,
                                    value=padding_color)
        return new_im

    @classmethod
    def preprocess(cls, imgs: list[np.ndarray]):
        input_tensor = np.ndarray((len(imgs), 3, 96, 128), np.float32)
        for i in range(len(imgs)):
            im = cls.transform_image(imgs[i])
            im = np.expand_dims(im, axis=0)
            input_tensor[i] = im
        return input_tensor

    @classmethod
    def softmax(cls, x):  # noqa
        """Compute softmax values for each sets of scores in x."""
        return np.exp(x - np.max(x)) / np.exp(x - np.max(x)).sum()

    @classmethod
    def postprocess_result(cls, output_tensor: np.ndarray) -> list[list[tuple[Any, Any]]]:
        results = []
        for i in range(output_tensor.shape[0]):
            row = output_tensor[i:i + 1]
            # softmax to get percent of certainty
            probabilities = cls.softmax(row)
            a = np.argsort(probabilities)
            top3 = [a[0][-1], a[0][-2], a[0][-3]]
            # print (top3)
            d = []
            for j in top3:
                t = classes.ENDEIS[j], round(100 * probabilities[0][j], 2)
                d.append(t)
            results.append(d)
            # s = '{0:.10f}'.format(round(probabilities[0][i], 4))
            # print(f'{SR1_JohnyLetter.REV_CLASS_MAP[i]}({i}) = {s}')
        return results

