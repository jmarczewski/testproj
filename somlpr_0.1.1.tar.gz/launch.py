# !/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.12"
# dependencies = [
#     'grpcio', 'loguru', 'openvino', 'numpy', 'opencv-python' ,'googleapis-common-protos' ,'webcolors' ,'tomlkit',
#     'setuptools', 'cython', 'aiohttp', 'cryptography'
# ]
# ///

# above shebang is used by uv to build virtual environment on first run '''

import argparse
import textwrap
import asyncio
from typing import Awaitable, Any

from loguru import logger
import aimodels
import config
import db

__version__ = '0.0.4'

__author__ = "Jakub Marczewski "
__copyright__ = "Copyright 2024, Jakub Marczewski"


#  Main launcher file for compiled SoMLPR server in grpc mode  #


# set up CLI arguments and help
# support multiline help in argparse
class RawFormatter(argparse.HelpFormatter):
    def _fill_text(self, text, width, indent):
        return "\n".join([textwrap.fill(line, width) for
                          line in textwrap.indent(textwrap.dedent(text), indent).splitlines()])


parser = argparse.ArgumentParser(formatter_class=argparse.RawTextHelpFormatter)

parser.add_argument("command", type=str, nargs='?', default='start',
                    help=textwrap.dedent('''
                                           specify command to execute:
                                           - start  : start the server ( default )
                                           - backup : backup the config file 
                                           '''))

parser.add_argument("-c", "--config", type=str,
                    help="specify config file to use")

parser.add_argument("-d", "--device", type=str,
                    help=textwrap.dedent('''
                         choose openvino inference device:
                         - auto, cpu, gpu , gpu.0, gpu.1.0, etc. ( see openvino docs )

                         ( defaults to AUTO )'''))

parser.add_argument('-g', '--grpc', type=str, action='append',
                    help=textwrap.dedent('''
                       expose grpc api on these interfaces and ports:
                        
                        -use ip:port format for IPv4 ie. 0.0.0.0:50051
                        -use []:port notation for IPV6 ie, [::1]:50051'''))

parser.add_argument('-r', '--rest', type=str, action='append',
                    help=textwrap.dedent('''
                       expose rest api on these interfaces and ports:

                        -use ip:port format for IPv4 ie. 0.0.0.0:50051
                        -use []:port notation for IPV6 ie, [::1]:50051'''))

parser.add_argument("-v", "--verbose", action="store_true", help="increase output verbosity")

args = parser.parse_args()


# main entry point
def main():
    config.load(args.config)
    config.args = args

    match args.command:

        case 'start' | 'run':
            run_command_start()
            return
        case _:
            logger.error(f'Unknown command: {args.command}')
            exit(-2)


# run start command ( default )
def run_command_start():
    coroutines: list[Awaitable] = []

    # create grpc api handling
    if len(config.grpc_bindings()) > 0:
        import api_grpc
        coroutines.append(api_grpc.serve())

    # create rest api handling
    if len(config.rest_bindings()) > 0:
        import api_rest
        coroutines.append(api_rest.serve())

    # load AI Models
    if len(coroutines) == 0:
        logger.error('No bindings. Set GRPC or Rest API bindings in config file or as -g or -r cli parameters')
        exit(-1)

    # start database backend
    coroutines.append(db.database_serve())

    # load AI Models

    aimodels.AiModels.load_models(config.models)

    # start apis
    async def start_apis():
        await asyncio.gather(*coroutines)

    try:
        asyncio.run(start_apis())
    except KeyboardInterrupt:
        logger.info("Ctrl+Z close signal caught.")
        exit(0)
    except Exception as ex:
        logger.error(f'{type(ex)} error in asyncio runner', ex)
        exit(0)




if __name__ == '__main__':
    main()
