# cython: language_level=3
import asyncio
import os
import sys
import numpy as np
import openvino as ov
import time

import config
import popo
import db
import graphics
from popo import SnapCommand, PlatoItems, CameraCommand, TrackerSceneCommand, TrackerVehicleCommand
from som import AiModel, AiEngineType, InferFlags, InferParameters, SomError, CompiledModel, Duration
import processing as prcs
from typing import Self, List
from loguru import logger
import argparse

total_durations = []
total_traker_durations = []

class AiModels:
    all_loaded_aimodels: list[Self] = []

    def __init__(self):
        self.models: dict[str, AiModel] = dict()
        self.defaults: dict[AiEngineType, AiModel] = dict()
        self.total_durations = []
        self.description: str | None = None

    @classmethod
    def load_models(cls, models: list[AiModel] | None = None, description: str = None) -> Self:
        aim = AiModels()
        # default_models = [
        #     ['_plato_t_model', 'plato/weights/PLATO6K_yolox_t.xml', {'type': 'PLATO', 'default': 1}],
        #     ['_plato_s_model', 'plato/weights/PLATO6K_yolox_s.xml', {'type': 'PLATO', 'default': 0}],
        #     ['simba_n_model', 'simba/weights/SL1_simba_n.xml', {'type': 'SIMBA', 'default': 1}],
        #     ['_simba_t_model', 'simba/weights/SL1_simba_t.xml', {'type': 'SIMBA', 'default': 0}],
        #     ['_simba_s_model', 'simba/weights/SL1_simba_s.xml', {'type': 'SIMBA', 'default': 0}],
        #     ['_simba_m_model', 'simba/weights/SL1_simba_m.xml', {'type': 'SIMBA', 'default': 0}],
        #     ['_johny_model', 'johny/weights/SR1-9939_dynamic.xml', {'type': 'JOHNY', 'default': 1}],
        #     ['_endeis_model', 'endeis/weights/SE1-9670.xml', {'type': 'ENDEIS', 'default': 1}],
        #     ['_meili_model', 'meili/weights/EXT2_yolox_t_b4.xml', {'type': 'MEILI', 'default': 1}],
        # ]
        ts0 = time.perf_counter()
        core = ov.Core()
        # set OpenVino Core properties
        core.set_property({'CACHE_DIR': '~tmp_cache'})

        # load default config
        for m in models:
            # check relative paths in context of working dir ( pyInstaller frozen )
            if not os.path.exists(m.path):
                if not os.path.isabs(m.path):
                    # determine if application is a script file or frozen exe from PyInstaller
                    if getattr(sys, 'frozen', False):
                        application_path = os.path.dirname(sys.executable)  # for --onefile pyInstaller build
                        os.chdir(application_path)
                    else:
                        application_path = os.path.dirname(os.path.abspath(__file__))
                    m.path = os.path.join(application_path, m.path)  # noqa

            device = config.device()
            if device == "AUTO":
                device = 'CPU' if len(core.available_devices) == 1 else 'GPU'
            ts = time.perf_counter()
            ov_model = core.read_model(m.path)
            # if config.verbose():
            #     logger.debug(f'compiling {m.name} model for {device} device')
            m.compiled = core.compile_model(ov_model, device_name=device)
            aim.models[m.name] = m
            logger.debug(f'compiled {m.name} model in {time.perf_counter() - ts:.3f} sec [ {device} ]')
            if m.default:
                aim.defaults[m.type] = m
        logger.opt(colors=True).info(f'ML models loaded in <blue>{time.perf_counter() - ts0:.3f}</> sec')
        if description is None:
            if len(cls.all_loaded_aimodels) == 0:
                aim.description = 'default'
            else:
                aim.description = f'#{len(cls.all_loaded_aimodels) + 1}'
        cls.all_loaded_aimodels.append(aim)
        return aim


def select_model(engine_type: AiEngineType, params: InferParameters, aimodels: AiModels | None = None) -> AiModel:
    if aimodels is None:
        aimodels = AiModels.all_loaded_aimodels[0]
    available = [aimodels.models[x] for x in aimodels.models if aimodels.models[x].type == engine_type]
    mapping = {AiEngineType.PLATO: [params.plato_name, params.plato_speed],
               AiEngineType.SIMBA: [params.simba_name, params.simba_speed],
               AiEngineType.JOHNY: [params.johny_name, params.johny_speed],
               AiEngineType.MEILI: [params.plato_name, params.meili_speed],
               AiEngineType.ENDEIS: [params.plato_name, params.endeis_speed], }
    ''' check for override specific model name '''
    if mapping[engine_type][0] is not None:
        try:
            return aimodels.models[mapping[engine_type][0]]
        except KeyError:
            logger.warning(f'No model with name "{mapping[engine_type][0]}" found.')
    speed = params.speed
    if mapping[engine_type][1] != -1:
        speed = mapping[engine_type][1]
    if speed == -1:
        speed = 2  # default to 2
    exact = [x for x in available if x.speed == speed]
    if len(exact) == 1:
        return exact[0]
    if len(exact) > 1:
        if InferFlags.SINGLE_PLATE in params.flags:
            for x in exact:
                if 'single' in x.tags:
                    return x
        return exact[0]  # no
    if InferFlags.ALT_FASTER in params.flags:
        ''' if no exact match found pick faster engine if ALT_FASTER set'''
        faster = [x for x in available if x.speed < speed]
        faster.sort(key=lambda x: x.speed)
        try:
            return faster[0]
        except IndexError:
            pass
    else:
        ''' get slower '''
        slower = [x for x in available if x.speed > speed]
        slower.sort(key=lambda x: x.speed)
        try:
            return slower[0]
        except IndexError:
            pass
    logger.warning('Engine selection chain ending. Selecting default model')
    return aimodels.defaults[engine_type]


# region ****   inference chains region  ****


class InferenceEngine:

    def __init__(self):
        self._close_event = asyncio.Event()
        self._queue_snap = asyncio.Queue[SnapCommand]()
        self._queue_cams = asyncio.Queue[CameraCommand]()
        self._queue_tracker_scene = asyncio.Queue[TrackerSceneCommand]()
        self._queue_tracker_vehicle = asyncio.Queue[TrackerVehicleCommand]()

        self.task = None

    def start(self):
        self._close_event.set()
        loop = asyncio.get_event_loop()
        self.task = loop.create_task(self.queue_worker(), name='DEFAULT INFER asyncio task')

    def close(self):
        self._close_event.set()

    async def enqueue_snap(self, cmd: SnapCommand) -> None:
        if cmd:
            try:
                await self._queue_snap.put(cmd)
            except Exception as ex:
                raise ex

    async def enqueue_tracker_scene(self, frame: TrackerSceneCommand) -> None:
        if frame is not None:
            await self._queue_tracker_scene.put(frame)

    async def enqueue_tracker_vehicle(self, vehicle: TrackerVehicleCommand) -> None:
        if vehicle is not None:
            await self._queue_tracker_vehicle.put(vehicle)

    async def queue_worker(self):

        async def process_snap() -> None | SomError:
            if self._queue_snap.qsize() > 0:
                obj = await self._queue_snap.get()
                try:
                    obj.scan_result = await DEFAULT_ENGINE.infer(obj)
                    if obj.no_copyright == 0:
                        await db.queue.put(obj)
                    obj.finished_event.set()
                except Exception as ex:
                    return SomError('error processing snapshot',
                                    SomError.ErrorCodes.ENGINE_INTERNAL_ERROR, ex)

        async def process_tracker_scene() -> None | SomError:
            waiting = self._queue_tracker_scene.qsize()
            if waiting > 5:
                print(f"WAITING {waiting}")
            if waiting > 0:
                obj = await self._queue_tracker_scene.get()
                try:
                    obj.scan_result = await DEFAULT_ENGINE.infer_tracker_scene(obj)
                    obj.finished_event.set()
                    pass
                except Exception as ex:
                    return SomError('error processing snapshot',
                                    SomError.ErrorCodes.ENGINE_INTERNAL_ERROR, ex)

        async def process_tracker_vehicle() -> None | SomError:
            if self._queue_tracker_vehicle.qsize() > 0:
                obj = await self._queue_tracker_vehicle.get()
                try:
                    obj.scan_result = await DEFAULT_ENGINE.infer_tracker_vehicle(obj)
                    obj.finished_event.set()
                    pass
                except Exception as ex:
                    return SomError('error processing tracker vehicle',
                                    SomError.ErrorCodes.ENGINE_INTERNAL_ERROR, ex)

        self._close_event.clear()
        while not self._close_event.is_set():
            try:
                await process_snap()  # process snapshots in queue
                await asyncio.sleep(0.0001)
                await process_tracker_scene()  # process tracker scene in queue
                await asyncio.sleep(0.0001)
                await process_tracker_vehicle()  #
                await asyncio.sleep(0.0001)
            except Exception as ex:
                logger.exception('Snap Inference engine queue worker error', ex)
        logger.debug('closed inference chain queue worker')
        return None

    # region snapshot inference chain

    async def infer(self, request: SnapCommand) -> PlatoItems:
        try:
            global total_durations
            scene = self.infer_scene(request.im, duration=None, params=request.parameters)
            symbols = self.infer_symbols(scene, duration=scene.duration, params=request.parameters)
            scene.append_symbol_info(symbols)
            artefacts = self.infer_artefacts(scene, duration=scene.duration, params=request.parameters)
            scene.append_artefact_info(artefacts)
            if InferFlags.NO_COLOR not in request.parameters.flags:
                [graphics.append_color_of_vehicle(x) for x in scene.plates + scene.rogue_vehicles]
            total_durations.append(scene.duration)
            total_durations = total_durations[-1000:]
            if config.verbose():
                scene.duration.log_to_console()
            return scene
        except Exception as ex:
            logger.exception(f'Failed to run inference ({type(ex)})', ex)
            request.result = ex
        finally:
            pass

    def infer_scene(self, imgs: np.ndarray | List[np.ndarray],
                    duration: Duration = None,
                    params: InferParameters = InferParameters(),
                    plato: CompiledModel | None = None,
                    ) -> popo.PlatoItems | None:
        ts = time.perf_counter()
        try:
            if imgs is None:
                return None
            if isinstance(imgs, np.ndarray):
                im = imgs
            elif len(imgs) == 1:
                im = imgs[0]
            else:
                raise NotImplementedError("Multiple images in snapshot are not supported yet")
            duration = duration or Duration()
            input_tensor, ratio = prcs.PlatoProcessing.preprocess(im)
            if plato is None:
                plato = select_model(AiEngineType.PLATO, params)
            output_tensor = plato.compiled(input_tensor)[0]
            predictions = prcs.PlatoProcessing.postprocess(output_tensor, ratio)
            duration.mark_infer_plato(time.perf_counter() - ts)
            if predictions is None:
                return None
            frame = popo.PlatoItems.parse(predictions, im)
            frame.duration = duration
            if InferFlags.SINGLE_PLATE in params.flags:
                frame.limit_to_single_plate()  # remove all but largest area plate
            return frame
        except Exception as ex:  # noqa
            logger.exception('Failed to infer scene (frame)', ex)
            return None
        finally:
            if duration is not None:
                duration.mark_frame(time.perf_counter() - ts)

    def infer_symbols(self, frame: popo.PlatoItems,
                      params: InferParameters,
                      simba: CompiledModel | None = None,
                      johny: CompiledModel | None = None,
                      duration: Duration = None) -> list[popo.SimbaItems] | None:
        ts_chain = time.perf_counter()
        ts = ts_chain
        if duration is None:
            duration = frame.duration
        try:
            ''' find symbols in plate images (simba)'''
            input_tensor, extras = prcs.SimbaProcessing.preprocess(frame.plate_images())
            if simba is None:
                simba = select_model(AiEngineType.SIMBA, params)
            output_tensor = simba.compiled(input_tensor)[0]
            predictions = prcs.SimbaProcessing.postprocess(output_tensor, extras)
            if duration is not None:
                duration.mark_infer_simba(time.perf_counter() - ts)
            symbols = popo.SimbaItems.parse(predictions, frame.plate_images())
            im_symbols = []
            for symbol in symbols:
                im_symbols.extend(symbol.symbol_images())
            ''' classify symbols ( johny ) '''
            ts = time.perf_counter()
            input_tensor = prcs.JohnyProcessing.preprocess(im_symbols)
            if johny is None:
                johny = select_model(AiEngineType.JOHNY, params)
            output_tensor = johny.compiled(input_tensor)[0]
            classified = prcs.JohnyProcessing.postprocess_result(output_tensor)
            idx = 0
            for symbol in symbols:
                for s in symbol.symbols:
                    s.top3 = classified[idx]
                    idx += 1
            if duration is not None:
                duration.mark_infer_johny(time.perf_counter() - ts)
            return symbols
        except Exception as ex:  # noqa
            logger.exception('Failed to infer symbols', ex)
            return None
        finally:
            if duration is not None:
                duration.mark_symbols(time.perf_counter() - ts_chain)

    def infer_artefacts(self, frame: popo.PlatoItems,
                        params: InferParameters,
                        meili: CompiledModel | None = None,
                        endeis: CompiledModel | None = None,
                        duration: Duration = None) -> popo.MeiliItems | None:
        ts_chain = time.perf_counter()
        try:
            ''' Find artefacts in images with Meili model '''
            ts = time.perf_counter()
            if duration is None:
                duration = frame.duration
            images = frame.plate_images()
            input_tensor, extras = prcs.MeiliProcessing.preprocess(images)
            if meili is None:
                meili = select_model(AiEngineType.MEILI, params)
            output_tensor = meili.compiled(input_tensor)[0]
            meili_predictions = prcs.MeiliProcessing.postprocess(output_tensor, extras)
            if duration is not None:
                duration.mark_infer_meili(time.perf_counter() - ts)
            countries = popo.MeiliItems.parse(meili_predictions, images)
            ''' classify artefacts with endeis model '''
            ts = time.perf_counter()
            input_tensor = prcs.EndeisProcessing.preprocess(countries.get_images())
            if endeis is None:
                endeis = select_model(AiEngineType.ENDEIS, params)
            output_tensor = endeis.compiled(input_tensor)[0]
            endeis_predictions = prcs.EndeisProcessing.postprocess_result(output_tensor)
            if duration is not None:
                duration.mark_infer_endeis(time.perf_counter() - ts)
            countries.append_endeis_inference(endeis_predictions)
            return countries
        except Exception as ex:  # noqa
            logger.exception('Failed to infer symbols', ex)
            return None
        finally:
            if duration is not None:
                duration.mark_artefacts(time.perf_counter() - ts_chain)

    # endregion

    # region tracker inference chain

    async def infer_tracker_scene(self, obj: TrackerSceneCommand):
        """ Infer the scene (vehicles, plates) for a tracker """
        try:
            global total_durations
            global total_traker_durations
            scene = self.infer_scene(obj.im, duration=None, params=obj.parameters)
            if scene is None:
                return
            total_durations.append(scene.duration)
            total_durations = total_durations[-1000:]
            total_traker_durations.append(scene.duration)
            total_traker_durations = total_traker_durations[-1000:]
            scene.duration.log_to_console()
            obj.detections = scene
        except Exception as ex:
            logger.exception('Failed to infer tracker scene', ex)
            raise

    async def infer_tracker_vehicle(self, obj: TrackerVehicleCommand):
        """Infer Symbols and optionally artefacts for tracker objects """
        try:
            global total_durations
            global total_traker_durations
            for detection in obj.detections:
                symbols = self.infer_symbols(detection, duration=detection.duration, params=obj.parameters)
                detection.append_symbol_info(symbols)
                artefacts = self.infer_artefacts(detection, duration=detection.duration, params=obj.parameters)
                detection.append_artefact_info(artefacts)
                if InferFlags.NO_COLOR not in obj.parameters.flags:
                    [graphics.append_color_of_vehicle(x) for x in detection.plates + detection.rogue_vehicles]
                total_durations.append(detection.duration)
                total_traker_durations.append(detection.duration)

            total_durations = total_durations[-1000:]
            total_traker_durations = total_traker_durations[-1000:]
            return None
        except Exception as ex:
            logger.exception('Failed to infer tracker vehicle', ex)
            raise
    #
    # async def infer_tracker_symbols(self, frame: PlatoItems, parameters: InferParameters):
    #     """ infer symbols for a tracker """
    #
    #
    #     # TODO  infer symbols for tracker
    #     return None
    #
    # async def infer_tracker_artefacts(self, frame: PlatoItems, parameters: InferParameters):
    #     """ infer symbols for a tracker """
    #     # TODO  infer artefacts for tracker
    #     return None

    # endregion


# endregion

DEFAULT_ENGINE = InferenceEngine()


def infer(request: SnapCommand) -> PlatoItems | Exception:
    return DEFAULT_ENGINE.infer(request)


def infer_scene(im: np.ndarray,
                duration: Duration = None,
                params: InferParameters = InferParameters(),
                plato: CompiledModel | None = None,
                ) -> popo.PlatoItems | None:
    return DEFAULT_ENGINE.infer_scene(im, duration=duration,
                                      params=params,
                                      plato=plato)


def infer_symbols(frame: popo.PlatoItems,
                  params: InferParameters,
                  simba: CompiledModel | None = None,
                  johny: CompiledModel | None = None,
                  duration: Duration = None) -> list[popo.SimbaItems] | None:
    return DEFAULT_ENGINE.infer_symbols(frame, params, simba=simba, johny=johny, duration=duration)


def infer_artefacts(frame: popo.PlatoItems,
                    params: InferParameters,
                    meili: CompiledModel | None = None,
                    endeis: CompiledModel | None = None,
                    duration: Duration = None) -> popo.MeiliItems | None:
    return DEFAULT_ENGINE.infer_artefacts(frame, params, meili=meili, endeis=endeis, duration=duration)


if __name__ == '__main__':
    # loop = asyncio.get_event_loop()
    # task = loop.create_task(DEFAULT_ENGINE.queue_worker(), name='DEFAULT INFER asyncio task')
    DEFAULT_ENGINE.start()
    print('Press Ctrl+{0} to exit'.format('Break' if os.name == 'nt' else 'C'))
    # Execution will block here until Ctrl+C (Ctrl+Break on Windows) is pressed.
    try:
        asyncio.get_event_loop().run_forever()
    except (KeyboardInterrupt, SystemExit):
        pass
