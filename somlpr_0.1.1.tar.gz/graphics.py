import numpy as np
from webcolors import rgb_to_name, names, name_to_rgb, rgb_to_hex
from contextlib import suppress
from typing import Sequence
from popo import FoundPlate, FoundVehicle


__author__ = "Jakub Marczewski "
__copyright__ = "Copyright 2024, Jakub Marczewski"

# list of name: (r,g,b) of css3 colors
rgb_names = {name_to_rgb(x): x for x in names('css3')}


def cut_x1y1x2y2_rect(im: np.ndarray, rect: list[int]) -> np.ndarray:
    """ cur top-left, bottom right defined rect from image"""
    return im[rect[1]:rect[3], rect[0]:rect[2]]


def expand_x1y1x2y2_rect(rect: Sequence[int], percent: float, clip_to: Sequence[int] | None = None) -> list[int]:
    """ expand rect in all directions ( does not go outside clip_to if clip_to shape is specified )"""
    w = rect[2] - rect[0]
    h = rect[3] - rect[1]
    if clip_to is not None:
        nx1 = max(0, rect[0] - int(w * percent / 2))
        ny1 = max(0, rect[1] - int(h * percent / 2))
        nx2 = min(clip_to[0], rect[2] + int(w * percent / 2))
        ny2 = min(clip_to[1], rect[3] + int(h * percent / 2))
    else:
        nx1 = rect[0] - int(w * percent / 2)
        ny1 = rect[1] - int(h * percent / 2)
        nx2 = rect[2] + int(w * percent / 2)
        ny2 = rect[3] + int(h * percent / 2)
    return [nx1, ny1, nx2, ny2]


def colour_dist(fst, snd):
    """ color distance between two colors """
    rm = 0.5 * (fst[:, 0] + snd[:, 0])
    rgb = (fst - snd) ** 2
    t = np.array([2 + rm, 4 + 0 * rm, 3 - rm]).T
    return np.sqrt(np.sum(t * rgb, 1))


def closest_color(rgb: tuple[int, int, int]) -> str:
    """ get name of closest color from the css3 set"""
    min_colours = {}
    for key in rgb_names:
        name = rgb_names[key]
        r_c, g_c, b_c = key
        rd = (r_c - rgb[0]) ** 2
        gd = (g_c - rgb[1]) ** 2
        bd = (b_c - rgb[2]) ** 2
        min_colours[(rd + gd + bd)] = name
    return min_colours[min(min_colours.keys())]


def append_color_of_vehicle(veh: FoundPlate | FoundVehicle, draw: bool = False):
    """ pick out some test pixels and figure out the car color  """
    arm = max(3, int(max(veh.height(), veh.width()) / 15))
    obj = veh if isinstance(veh, FoundVehicle) else veh.vehicle
    if obj is None:
        return
    results = []
    c = obj.center()
    rr = obj.rect
    points = [  # probing points
        [c[0] - 8 * arm, rr[1] + 5 * arm],
        [c[0] + 8 * arm, rr[1] + 5 * arm],
        [c[0] - 8 * arm, rr[1] + 8 * arm],
        [c[0] + 8 * arm, rr[1] + 8 * arm],
    ]
    for cc in points:
        # get 2*arm x 2*arm cross sample
        pixels: list[np.ndarray] = [
            veh.parent.im[cc[1]:cc[1] + 1, cc[0] - arm:cc[0] + arm].flatten().reshape(2 * arm, 3),
            veh.parent.im[cc[1] - arm:cc[1] + arm, cc[0]:cc[0] + 1].flatten().reshape(2 * arm, 3)
        ]
        ''' debug draw crosses on '''
        if draw:
            veh.parent.im[cc[1]:cc[1] + 1, cc[0] - arm:cc[0] + arm] = (0, 0, 255)
            veh.parent.im[cc[1] - arm:cc[1] + arm, cc[0]:cc[0] + 1] = (0, 0, 255)

        d = np.concatenate(pixels)
        b = d[:, 0]
        g = d[:, 1]
        r = d[:, 2]
        ptp: int = int(np.ptp(b)) + int(np.ptp(g)) + int(np.ptp(r))

        def mode(arr: np.ndarray) -> int:
            values, counts = np.unique(arr, return_counts=True)
            index = np.argmax(counts)
            return int(values[index])

        mb = mode(b)
        mg = mode(g)
        mr = mode(r)
        ''' sort results by lightest color , then most uniformity '''
        results.append((ptp, mr + mb + mg, (mr, mg, mb)))
        if ptp < 10:
            break
    results.sort(key=lambda x: (-x[1], x[0]))
    rgb = results[0][2]
    try:
        color_name = rgb_to_name(rgb, spec='css3')
    except ValueError:
        color_name = closest_color(rgb)
    obj.color = color_name, rgb_to_hex(rgb)


# def rgb_to_hex(r, g, b):
#     return '#{:02x}{:02x}{:02x}'.format(r, g, b)


# def line(p1, p2):
#     a = b = 0
#     if p1[0] == p2[0]:
#         return 0, p1[0]
#     try:
#         a, b = np.polyfit((p1[0], p2[0]), (p1[1], p2[1]), 1)  # noqa
#     except Exception as lex:
#         logger.error(f'Polyfit not working - {lex} ( Non-AI plate segmentation')
#     return a, b


def line2points(p1, p2):
    """ Very fast generate int line points between 2 points """
    if p1[0] == p2[0]:
        # horizontal line
        diff = []
        if p1[1] > p2[1]:
            for y in range(p1[1], p2[1], -1):
                diff.append([p1[0], y])
            diff.append(p2)
        else:
            for y in range(p1[1], p2[1]):
                diff.append([p1[0], y])
            diff.append(p2)
        return np.asarray(diff)
    try:
        # very fast algorithm
        ends = np.array([p1, p2])
        d0, d1 = np.diff(ends, axis=0)[0]
        if np.abs(d0) > np.abs(d1):
            with suppress(RuntimeWarning):
                return np.c_[np.arange(ends[0, 0], ends[1, 0] + np.sign(d0), np.sign(d0), dtype=np.int32),
                np.arange(ends[0, 1] * np.abs(d0) + np.abs(d0) // 2,
                          ends[0, 1] * np.abs(d0) + np.abs(d0) // 2 + (np.abs(d0) + 1) * d1, d1,
                          dtype=np.int32) // np.abs(d0)]
        else:
            return np.c_[np.arange(ends[0, 0] * np.abs(d1) + np.abs(d1) // 2,
                                   ends[0, 0] * np.abs(d1) + np.abs(d1) // 2 + (np.abs(d1) + 1) * d0, d0,
                                   dtype=np.int32) // np.abs(d1),
            np.arange(ends[0, 1], ends[1, 1] + np.sign(d1), np.sign(d1), dtype=np.int32)]
    except Exception as ex:  # noqa
        def line_backup(pb1, pb2):
            try:
                a, b = np.polyfit((pb1[0], pb2[0]), (pb1[1], pb2[1]), 1)  # noqa
            except Exception as lex:
                raise lex
            return a, b

        result = []
        a, b = line_backup(p1, p2)
        for x in range(min(p1[0], p2[0]), max(p1[0], p2[0])):
            y = int(a * x + b)
            result.append([x, y])
        return np.asarray(result)
