import datetime
import sqlite3
import sys

import aiosqlite
import asyncio
import time
import json
import os
import cv2
import numpy as np
from typing import Awaitable, Any
from loguru import logger
import config
import popo
import uuid
import utils

MAX_DAYS_ACTIVE = 30  # upload current db and start a new one if current is older than x days
MAX_BYTE_SIZE = 524288000  # upload current db and start a new one if file size > 500 Mb
MAX_SCANS = 20  # upload current db and start a new one if amount of scans > 1000
EVALUATE_SPAN = 30  # evaluate model every x  seconds

queue: asyncio.Queue = asyncio.Queue()
up_queue: asyncio.Queue = asyncio.Queue()
cam_ids: dict = { None: None}

async def _add_snapshot(db: aiosqlite.Connection, item: popo.SnapCommand) -> None:
    data = []
    for im in item.im:
        try:
            identifier, waiver = utils.generate_waiver(im)
            _, jpeg = cv2.imencode('.jpeg', im)
            extras = {'verify': item.verify, 'engine': item.verify_engine}
            if item.source_id not in cam_ids:
                cam_ids[item.source_id] = uuid.uuid4().hex
            source = cam_ids[item.source_id]
            plates = [x.grpc() for x in item.scan_result.plates]
            plates = [ popo.Serialization.json(x) for x in plates ]
            plates = [ json.loads(x) for x in plates ]

            #plates =popo.Serialization.json(x.grpc() for x in item.scan_result.plates)
            data.append((str(identifier),
                         jpeg.tobytes(),
                         waiver,
                         json.dumps(plates),
                         ##son.dumps(item.scan_result.plates) if item.scan_result else None,
                         source,
                         json.dumps(extras)
                         ))
        except Exception as ex:  # noqa
            logger.error(f'{type(ex)} error in _add_snapshot', ex)
            continue
    try:
        sql = 'INSERT INTO snapshots VALUES (?, ?, ?, ?, ?, ?)'
        await db.executemany(sql, data)
        await db.commit()
    except aiosqlite.Error as ex:
        logger.error(f'SQL error in db._add_snapshot', ex)
    except Exception as ex:  # noqa
        logger.error(f'General {type(ex)} in db._add_snapshot', ex)

async def create_gobal_db() -> None:
    pass

async def create_db(db: aiosqlite.Connection, index: int = -1) -> None:
    try:
        await db.execute('''
            CREATE TABLE IF NOT EXISTS info (
                prop_key TEXT PRIMARY KEY,
                prop_val TEXT
            )
            ''')
        await db.execute('''
            CREATE TABLE IF NOT EXISTS snapshots
            (
                id BLOB PRIMARY KEY,
                image BLOB,
                waiver TEXT,
                plates JSON,
                source TEXT,         
                verify JSON
            )
            ''')
        await _insert_info_if_missing(db, 'created', datetime.date.strftime(datetime.date.today(), '%Y-%m-%d'))
        await _insert_info_if_missing(db, 'index', str(index))
        await _insert_info_if_missing(db, 'country', config.country() or 'N/A')
        await _insert_info_if_missing(db, 'certificate', utils.get_server_certificate())
        await _insert_info_if_missing(db, 'engine_id', config.engine_id())
        await _insert_info_if_missing(db, 'geolocation', await utils.geolocate())

        await db.commit()
    except Exception as ex:  # noqa
        raise


class DumpDbError(Exception):
    """ an error that is raised to exit db connection and copy db to disk"""

    def __init__(self, reason):
        self.uuid = uuid.uuid4().hex
        logger.info(f'dumping database to disk...A_{self.uuid} (reason is {reason})')


async def _sleep(seconds: int) -> None:
    """ simple sleep function that tests override to speed things up """
    await asyncio.sleep(seconds)


async def _insert_info_if_missing(db: aiosqlite.Connection, key: str, value: str) -> None:
    """ add row to info table only if primary key is not already present """
    try:
        sql = 'INSERT INTO info VALUES (?, ?) ON CONFLICT DO NOTHING'
        await db.execute(sql, (key, value))
    except aiosqlite.Error as ex:
        logger.error(f'SQL error in db._insert_info_if_missing (key={key})', ex)
    except Exception as ex:  # noqa
        logger.error(f'General {type(ex)} in db._insert_info_if_missing (key={key})', ex)


async def _update_info(db: aiosqlite.Connection, key: str, value: str) -> None:
    """ add or update row in info table """
    try:
        sql = 'UPDATE OR INSERT INTO info VALUES (?, ?)'
        await db.execute(sql, (key, value))
        await db.commit()
    except aiosqlite.Error as ex:
        logger.error(f'SQL error in db._update_info (key={key})', ex)
    except Exception as ex:  # noqa
        logger.error(f'General {type(ex)} in db._update_info (key={key})', ex)


async def _database_size(db: aiosqlite.Connection) -> int:
    """ get the size of the db in bytes """
    try:
        pc = await db.execute_fetchall('PRAGMA page_count')
        ps = await db.execute_fetchall('PRAGMA page_size')
        byte_count = pc[0][0] * ps[0][0]
        return byte_count
    except sqlite3.Error:
        return -1


async def _database_days_active(db: aiosqlite.Connection) -> int:
    """ get the size of the db in bytes """
    try:
        d = await db.execute_fetchall('SELECT propval FROM info WHERE propkey = "created" ')
        ts = datetime.datetime.strptime(d[0][0], '%Y-%m-%d').date()
        days = datetime.date.today() - ts
        return int(days.days)
    except sqlite3.Error:
        return -1


async def _database_should_swap(db: aiosqlite.Connection) -> str | None:
    """ evaluate if the db is ready for submitting """
    ts = time.time()
    total_entries = await db.execute_fetchall('SELECT COUNT(*) FROM snapshots')
    print('total entries now at ', total_entries[0][0], time.time() - ts)
    if total_entries[0][0] >= MAX_SCANS:
        return f'entries = {total_entries[0][0]}'
    days_active = await _database_days_active(db)
    if days_active > MAX_DAYS_ACTIVE:
        return 'days active'
    db_size = await _database_size(db)
    if db_size > MAX_BYTE_SIZE:
        return f'size={db_size}'
    return None


async def database_upload() -> None:
    """ upload databases that are ready for submission """
    while 1:
        try:
            await _sleep(360)
            files = []
            for fn in os.listdir(os.path.join(config.working_dir(), '~tmp_cache')):
                if fn.endswith('.dat'):
                    files.append(fn)
            for f in files:
                print(f)
            match f[0]:
                case 'A':
                    ''' sum up db and prepare for upload'''

                case _:
                    logger.warning(f'Unknown dat file prefix {f[0]}_')
        except asyncio.CancelledError:
            return


async def database_serve():
    global queue
    dbname = os.path.join(config.working_dir(), 'scans.sqlite3')
    ts = time.time()
    while 1:
        try:
            async with aiosqlite.connect(dbname) as db:
                await create_db(db)
                while 1:

                    ''' check for db full every 30 minutes '''

                    if time.time() - ts >= EVALUATE_SPAN:
                        ''' it' been EVALUATE_SPAN seconds, let's evaluate db for sending'''
                        reason = await _database_should_swap(db)
                        if reason  is not None:
                            ''' we need to swap the db for new one. Close connections, rename, etc.'''
                            raise DumpDbError(reason)
                        ts = time.time()
                        pass

                    ''' process queue'''

                    if not queue:
                        await asyncio.sleep(.5)
                        continue
                    try:
                        count = queue.qsize()
                        if count == 0:
                            await asyncio.sleep(.5)
                            continue
                        if count >= 10 and count % 10 == 0:
                            logger.warning(f'database queue is long ({count} items)')
                        item = await queue.get()
                        if isinstance(item, popo.SnapCommand):
                            if item.no_copyright == 1:
                                continue
                            await _add_snapshot(db, item)
                    except asyncio.CancelledError:
                        raise
                    except Exception as qex:
                        logger.error(f'{type(qex)} in database read/write', qex)
        except DumpDbError as dex:
            await asyncio.sleep(1)
            if not os.path.exists(os.path.join(config.working_dir(), '~tmp_cache')):
                os.mkdir(os.path.join(config.working_dir(), 'tmp_cache'))
            dst = os.path.join(config.working_dir(), '~tmp_cache', f'A_{dex.uuid}.dat')
            for i in range(3):
                try:
                    os.replace(dbname, dst)
                    break
                except Exception as ex:  # noqa
                    logger.error(f'Unable to rename database ( attempt {i + 1} ) - ({type(ex)}){ex}')
                    await asyncio.sleep(1)
                if os.path.exists(dbname):
                    logger.error(f'Gave up on renaming db')
            continue
        except asyncio.CancelledError:
            return
        except Exception as ex:
            logger.error(f'{type(ex)} in database connection - {ex}', ex)
            await asyncio.sleep(3)
            continue


def main():
    config.load()
    logger.debug('config loaded')

    # start apis
    async def start_apis():

        def random_plate():
            chars = 'ABCDEFGHIJKLMNOPQURSTC1234567890'
            r = ''
            length = random.randint(4, 8)
            for i in range(length):
                r += chars[random.randrange(0, len(chars) - 1)]
            return r

        import random
        import popo
        plates = []

        # #t1 = asyncio.create_task(database_serve())
        # await asyncio.sleep(0)  # pre-python 3.12 hackt to get coro running
        # t2 = asyncio.create_task(database_upload())
        # await asyncio.sleep(0)  # pre-python 3.12 hackt to get coro running

        for i in range(700):
            if len(plates) == 0 or random.randrange(0, 10) <= 5:
                plate = random_plate()
                plates.append(plate)
            else:
                plate = random.choice(plates)
            snap = popo.SnapCommand()
            snap.source_id = random.choice([None, 'cam1', 'cam2'])
            snap.im = [np.random.rand(1080, 792, 3) * 255]
            snap.scan_result = popo.PlatoItems()
            snap.scan_result.plates = []
            if len(plates) > 0 and random.randrange(0, 10) <= 2:
                snap.scan_result.plates.append(random.choice(plates))
                snap.scan_result.plates.append(random.choice(plates))

            else:
                snap.scan_result.plates.append(plate)
            await queue.put(snap)
            print('added to queue')
            await asyncio.sleep(random.uniform(0.15, 1.0))
        # await asyncio.gather(*coroutines)

    async def run_loop():
        coroutines: list[Awaitable] = [database_serve(), database_upload(), start_apis()]
        try:
            print('gathering')
            await asyncio.gather(*coroutines)
            print('after gather')

        except KeyboardInterrupt:
            logger.info("Ctrl+Z close signal caught.")
            exit(0)
        except Exception as ex:
            logger.exception(f'{type(ex)} error in asyncio runner', ex)
            exit(0)

    # coroutines: list[Awaitable] = [database_serve(), database_upload(), start_apis()]
    # try:
    #     await asyncio.gather(*coroutines)
    #
    # except KeyboardInterrupt:
    #     logger.info("Ctrl+Z close signal caught.")
    #     exit(0)
    # except Exception as ex:
    #     logger.error(f'{type(ex)} error in asyncio runner', ex)
    #     exit(0)

    asyncio.run(run_loop())
    # try:
    #
    #     asyncio.run(start_apis())
    #
    #
    # except KeyboardInterrupt:
    #     logger.info("Ctrl+Z close signal caught.")
    #     exit(0)
    # except Exception as ex:
    #     logger.error(f'{type(ex)} error in asyncio runner', ex)
    #     exit(0)


if __name__ == '__main__':
    main()
