# cython: language_level=3

from dataclasses import dataclass, field
from enum import IntFlag, Enum
from typing import Self, Any
from loguru import logger
from openvino import CompiledModel
import numpy as np



class InferFlags(IntFlag):
    DEFAULT = 0x00
    SINGLE_PLATE = 0x01
    ALT_FASTER = 0x04
    NO_EXTERNAL = 0x08
    NO_LOGO = 0x10
    NO_COLOR = 0x20
    FORCE_SMALL = 0x40


class InferType(Enum):
    SNAPSHOT = 0
    CAMERA = 1


@dataclass
class InferParameters:
    speed: int = -1

    flags: InferFlags = InferFlags.DEFAULT
    plato_speed: int = -1
    simba_speed: int = -1
    johny_speed: int = -1
    meili_speed: int = -1
    endeis_speed: int = -1

    plato_name: str | None = None
    johny_name: str | None = None
    simba_name: str | None = None
    meili_name: str | None = None
    endeis_name: str | None = None

    debug: bool = False
    included: list[tuple[int, int]] = field(default_factory=list)
    regions: str | None = None


@dataclass
class ClientId:
    api_key: str | None = None


class AiEngineType(Enum):
    NONE = 0
    PLATO = 1
    SIMBA = 2
    ENDEIS = 3
    JOHNY = 4
    MEILI = 5


@dataclass
class AiModel:
    type: AiEngineType | str
    name: str
    path: str
    speed: int
    countries: list[str] = field(default_factory=list)
    active: bool = True
    default: bool = False
    tags: list[str] = field(default_factory=list)
    compiled: CompiledModel = None

    @classmethod
    def parse(cls, models_dicts: list[dict]) -> list[Self]:
        result = []
        err = []
        for item in models_dicts:
            try:
                model = AiModel(**item)
                try:
                    model.type = getattr(AiEngineType, model.type)
                except (ValueError, AttributeError) as ex:
                    pass
                result.append(model)
            except Exception as ex:  # noqa
                # logger.exception(ex)
                err.append(item)
        if len(err) > 0:
            logger.warning(f'{len(models_dicts) - len(err)} / {len(models_dicts)} models parsed correctly.'
                           f' -> models with errors: {", ".join([x.get("name", "????") for x in err])}')
        return result


class ModelNotFoundError(Exception):

    def __init__(self, message: str, models: list):
        self.models = models
        super().__init__(message)


class SomError(Exception):
    class ErrorCodes(Enum):
        OK = 0
        ENGINE_TIMEOUT = 1
        ENGINE_INTERNAL_ERROR = 2
        IMAGE_PROBLEM = 3
        NO_IMAGE = 4

    def __init__(self, message: str, code: ErrorCodes | int, base_err: Exception = None):
        self.base = base_err
        self.code = code
        self.message = message
        super().__init__(message)


class ModelInferenceError(Exception):

    def __init__(self, message: str, model: Any, ex: Exception | None = None):
        self.model = model
        self.inner = ex
        super().__init__(message)


class Duration:

    def __init__(self):
        self.chains = {
            'scene': [],
            'symbols': [],
            'artefacts': [],

        }
        self.infers = {
            AiEngineType.PLATO: [],
            AiEngineType.SIMBA: [],
            AiEngineType.MEILI: [],
            AiEngineType.JOHNY: [],
            AiEngineType.ENDEIS: [],
        }

    def total_chains(self) -> float:
        t = 0.0
        for key in self.chains:
            for x in self.chains[key]:
                t += x
        return round(t, 3)

    def total_infers(self) -> float:
        t = 0.0
        for key in self.infers:
            for x in self.infers[key]:
                t += x
        return round(t, 3)

    def mark_frame(self, secs: float):
        self.chains['scene'].append(round(secs, 3))

    def mark_symbols(self, secs: float):
        self.chains['symbols'].append(round(secs, 3))

    def mark_artefacts(self, secs: float):
        self.chains['artefacts'].append(round(secs, 3))

    def mark_infer_plato(self, secs: float):
        self.infers[AiEngineType.PLATO].append(round(secs, 3))

    def mark_infer_simba(self, secs: float):
        self.infers[AiEngineType.SIMBA].append(round(secs, 3))

    def mark_infer_johny(self, secs: float):
        self.infers[AiEngineType.JOHNY].append(round(secs, 3))

    def mark_infer_meili(self, secs: float):
        self.infers[AiEngineType.MEILI].append(round(secs, 3))

    def mark_infer_endeis(self, secs: float):
        self.infers[AiEngineType.ENDEIS].append(round(secs, 3))

    def log_to_console(self) -> str:
        logger.opt(ansi=True).debug(self)
        return str(self)

    def __repr__(self) -> str:
        s = f'total: <green>{self.total_chains()}</green> [sec]\n'
        c = '(chains): '
        i = '(infer): '
        if len(self.chains['scene']) > 0:
            value_chain = np.sum(self.chains['scene'])
            value_infer = np.sum(self.infers[AiEngineType.PLATO])
            diff = round(value_chain - value_infer, 3)
            s_diff = ''
            if diff != 0.0:
                s_diff = f'({"+" if diff > 0 else ""}{diff})'
            c += f'scene: {np.sum(self.chains["scene"])} {s_diff} ,'
        if len(self.chains['symbols']) > 0:
            value_chain = np.sum(self.chains['symbols'])
            value_infer = (np.sum(self.infers[AiEngineType.SIMBA]) +
                           np.sum(self.infers[AiEngineType.JOHNY]))
            diff = round(value_chain - value_infer, 3)
            s_diff = ''
            if diff != 0.0:
                s_diff = f'({"+" if diff > 0 else ""}{diff})'
            c += f'symbols: {np.sum(self.chains["symbols"])} {s_diff} ,'
        if len(self.chains['artefacts']) > 0:
            value_chain = np.sum(self.chains['artefacts'])
            value_infer = (np.sum(self.infers[AiEngineType.MEILI]) +
                           np.sum(self.infers[AiEngineType.ENDEIS]))
            diff = round(value_chain - value_infer, 3)
            s_diff = ''
            if diff != 0.0:
                s_diff = f'({"+" if diff > 0 else ""}{diff})'
            c += f'artefacts: {np.sum(self.chains["artefacts"])} {s_diff} ,'

        if c.endswith(','):
            c = f'{c.rstrip(", ")} [sec]\n'
        for key in self.infers:
            if len(self.infers[key]) > 0:
                i += f'{str(key).split(".")[1]}: {np.sum(self.infers[key])} ,'
        if i.endswith(','):
            i = f'{i.rstrip(", ")} [sec]\n'
        if len(c) > 0:
            s += f'   {c}'
        if len(i) > 0:
            s += f'   {i}'
        return s

        # def __repr__(self) -> str:

    #     return (f'total: {self.total_chains()} sec ('
    #             f'{"P" if len(self.infers[AiEngineType.PLATO]) > 0 else ""}'
    #             f'{"S" if len(self.infers[AiEngineType.SIMBA]) > 0 else ""}'
    #             f'{"J" if len(self.infers[AiEngineType.JOHNY]) > 0 else ""}'
    #             f'{"M" if len(self.infers[AiEngineType.MEILI]) > 0 else ""}'
    #             f'{"E" if len(self.infers[AiEngineType.ENDEIS]) > 0 else ""})')

    def __str__(self) -> str:
        s = f'total: {self.total_chains()}s\n'
        c = '(chains): '
        i = '(infer): '
        for key in self.chains:
            if len(self.chains[key]) > 0:
                c += f'{key}: {np.average(self.chains[key])}s ,'
        if c.endswith(','):
            c = f'{c.rstrip(", ")}\n'

        for key in self.infers:
            if len(self.infers[key]) > 0:
                i += f'{str(key).split(".")[1]}: {np.average(self.infers[key])}s ,'
        if i.endswith(','):
            i = f'{i.rstrip(", ")}\n'
        if len(c) > 0:
            s += f'{c}'
        if len(i) > 0:
            s += f'{i}'
        return s

    @classmethod
    def average(cls, instances: list[Self]) -> Self:
        pass
