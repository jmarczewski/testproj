# SoM-LPR
## Society of Mind License Plate Recognition



To Be done later on 