__author__ = "Jakub Marczewski "
__copyright__ = "Copyright 2024, Jakub Marczewski"

import datetime
import os
import sys
import uuid
from argparse import Namespace
from tomlkit import parse, load as tomlload, dump
from loguru import logger
from collections import Counter
from som import AiModel
import subprocess

""" 
  - This is not the configuration file. 
  
  * the config file is in  ... config/config.toml  file for system configuration   
  
  * config file lookup order :
    - config.toml   ( in main app directory )
    - config/config.toml
    - /etc/som/lpr/config.toml
    
    This file loads and validates the actual config file 
    
"""

configuration: dict | None = None  # main configuration dict used by the app
models: list[AiModel] | None = None
filename: str | None = None
loaded: bool = False
args: Namespace  # argparse parsed
app_folder: str | None = None


def grpc_bindings() -> list[str]:
    try:
        if args.grpc is not None and len(args.grpc) > 0:  # grpc
            return args.grpc
        if isinstance(configuration['basic']['grpc'], str):
            return [configuration['basic']['grpc']]
        return configuration['basic']['grpc']
    except (KeyError, ValueError) as ex:
        return []


def rest_bindings() -> list[str]:
    try:
        if args.rest is not None and len(args.rest) > 0:  # grpc
            return args.rest
        if isinstance(configuration['basic']['rest'], str):
            return [configuration['basic']['rest']]
        return configuration['basic']['rest']
    except (KeyError, ValueError) as ex:
        return []


def device() -> str:
    try:
        if args.device is not None:
            return args.device.upper().strip()
        return configuration['basic']['device'].upper().strip()
    except (KeyError, ValueError) as ex:
        return "AUTO"


def working_dir() -> str:
    global app_folder
    if app_folder:
        return app_folder
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.exists(os.path.join(current_dir, '..', "config")):
        app_folder = os.path.abspath(os.path.join(current_dir, '..', ))
        return app_folder
    if os.path.exists(os.path.join(current_dir, "config")):
        app_folder = os.path.abspath(current_dir)
        return app_folder
    raise IOError("config folder not found!")


def app_version() -> str:
    try:
        return configuration['meta']['version'].upper().strip()
    except (KeyError, ValueError) as ex:
        return "0.0.0.0"


def install_date() -> datetime.date:
    try:
        return datetime.datetime.strptime(configuration['meta']['installed'], '%Y-%m-%d')
    except:  # noqa
        return datetime.date.min


def engine_id() -> str:
    try:
        return configuration['meta']['engine_id'].strip()
    except (KeyError, ValueError) as ex:
        return str(uuid.uuid4())


def email() -> str | None:
    try:
        return configuration['advanced']['my_email'].strip()
    except (KeyError, ValueError) as ex:
        return None


def no_cc0() -> bool:
    try:
        r = bool(configuration['advanced']['no_cc0'])
        return r
    except:  # noqa
        return True


def ssl() -> bool:
    """ should we use ssl encryption """
    try:
        return bool(configuration['ssl']['ssl'])
    except (KeyError, ValueError) as ex:
        return False


def ssl_password() -> str | None:
    """ Password for private key file.
    Note: Auto-generated self-signed certificates don't have a password set. """
    try:
        pwd = configuration['ssl']['key_password'].strip()
        if len(pwd) == 0:
            return None
        return pwd
    except (KeyError, ValueError) as ex:
        return None


def verbose() -> bool:
    try:
        return args.verbose
    except:  # noqa
        return False


def country() -> str:
    try:
        return configuration['basic']['country']
    except:  # noqa
        return ''


def clip_directory() -> str | None:
    try:
        return configuration['advanced']['clip_directory']
    except (KeyError, ValueError) as ex:
        return None


def remote_config_allowed() -> bool:
    try:
        return bool(configuration['advanced']['remote_config'])
    except (KeyError, ValueError) as ex:
        return False


def clip_directory_not_set() -> bool:
    return clip_directory() is None or len(clip_directory()) == 0


def load(file: str = None) -> bool:
    global configuration, models, loaded
    configuration = _load_config_dict_from_file(file)
    ''' check metadata version, machine id, etc.'''
    update_metadata()
    ''' check integrity '''
    errors, warnings = check_config_integrity(configuration)
    if len(errors) > 0:
        for line in warnings:
            logger.opt(colors=True).warning(line)
        for line in errors:
            logger.opt(colors=True).error(line)
        exit(-1)
    if len(warnings) > 0:
        for line in warnings:
            logger.opt(colors=True).warning(line)
        logger.opt(colors=True).info(f'configuration loaded with {len(warnings)} warnings')
    ''' create ai-models'''
    models = AiModel.parse(configuration['model'])
    loaded = True
    return True


def _load_config_dict_from_file(file) -> dict | None:
    global filename
    # determine if application is a script file or frozen exe
    if getattr(sys, 'frozen', False):
        application_path = os.path.dirname(sys.executable)
        os.chdir(application_path)
    else:
        application_path = os.path.dirname(os.path.abspath(__file__))
    candidate_files = [
        os.path.join(application_path, 'config.toml'),
        os.path.join(application_path, 'config', 'config.toml'),
        'config.toml',
        'config/config.toml',
        'etc/som/lpr/config.toml'
    ]
    if file is not None:
        if not os.path.exists(file):
            logger.exception(f'specified config file does not exist : {file}')
        candidate_files.insert(0, file)
    for candidate in candidate_files:
        if os.path.exists(candidate):
            logger.debug(f'using config file {candidate}')
            filename = candidate
            try:
                with open(filename, 'r') as f:
                    r = tomlload(f)
                return r
            except Exception as ex:  # noqa
                logger.exception(ex)
                logger.error(f'Failed to load config file {candidate}')
                return None
    logger.error(f'No config file found!. Searched :\n  -> {" ; ".join(candidate_files)}')
    return None


def _load_config_from_text(text) -> dict:
    try:
        return parse(text)
    except Exception as ex:  # noqa
        logger.exception(ex)
        raise


def check_config_integrity(model_config) -> tuple[list[str], list[str]]:
    """ check toml model definition dict for error and warnings """
    TRUE = ['true', 'yes', '1', 1]  # noqa
    FALSE = ['false', 'no', '0', 0]  # noqa

    obligatory = ['type', 'path', 'speed', 'name']
    standard_models = 'PLATO', 'SIMBA', 'JOHNY', 'ENDEIS', 'MEILI'
    models = model_config.get('model')
    all_keys = ['type', 'path', 'speed', 'name', 'countries', 'tags', 'default', 'active', 'shape']

    errors = []
    warnings = []

    def model_id(m):  # noqa
        return m.get('name', f'index {list.index(models, m)}')

    ''' (errors) check for obligatory fields '''
    ''' (warnings) check for wrong value of active '''
    for i, m in enumerate(models):
        identifier = model_id(m)
        for key in obligatory:
            if key not in m:
                errors.append(f'model <blue>{identifier}</blue> is missing <blue>{key}</blue> key.')
        if 'active' in m and m['active'] not in TRUE + FALSE:
            warnings.append(f'model <blue>{identifier}</blue> property <green>active</green> is invalid')

    ''' (errors) check for multiple defaults / no defaults for each model type '''
    types = set([x['type'].upper() for x in model_config['model']])
    for t in types:
        defaults = [x for x in models if x.get('type', None) == t and str(x.get('default', '0')) in TRUE]
        if len(defaults) == 0:
            errors.append(f'no model of type <white>{t}</white> has <green>default</green> key set to'
                          f' <white>true</white>.')
        if len(defaults) > 1:
            identifiers = f"<blue>{'</blue>,<blue>'.join([model_id(x) for x in defaults])}</blue>"
            errors.append(f'multiple models of type <white>{t}</white> ({identifiers}) '
                          f'have <green>default</green> key set to <green>true</green>.')

    ''' (errors) check for non-unique names '''
    name_counts = Counter([x.get('name', 'NOT_SET') for x in models])
    repeated = [x for x in name_counts if name_counts[x] > 1]
    for name in repeated:
        errors.append(f'the model name <blue>{name}</blue> is not unique ( used {name_counts[name]} times ).')

    ''' (errors) check if speeds are a valid integer range '''
    for m in models:
        speed = m.get('speed', 'nan')
        if not isinstance(speed, int) or 0 < int(speed) > 10:
            errors.append(f'model <blue>{model_id(m)}</blue> speed is not an integer in range 0..10')

    ''' (errors) check for missing standard model types '''
    declared_types = [x.get('type', "NOT_SET") for x in models]
    for standard in standard_models:
        if standard not in declared_types:
            errors.append(f'missing at least one entry with required standard model <blue>{standard}</blue>.')

    ''' (errors) check for repeated weight path files '''
    path_counts = Counter([f"{os.path.abspath(x.get('path', '/'))}["
                           f"{'single' if 'single' in x.get('tags', []) else 'dynamic'}]" for x in models])
    repeated = [x for x in path_counts if path_counts[x] > 1]
    for url in repeated:
        repeated_models = [x for x in models if x.get('path', '/') == url]

        errors.append(f'the path <white>{url}</white> is repeated in {path_counts[url]} models.')

    ''' (warning) check for non-standard models'''
    for t in declared_types:
        if t not in standard_models:
            warnings.append(f'model type <white>{t}</white> is not a standard model.')

    ''' modify weight paths if base_weight_dir key exists and is an existing path '''
    basedir = model_config['advanced'].get('base_weight_dir', '')
    if os.path.exists(basedir):
        for m in models:
            if 'path' in m:
                if not os.path.exists(m['path']):
                    m['path'] = os.path.join(basedir, m['path'])
                if not os.path.isabs(m['path']):
                    m['path'] = os.path.abspath(m['path'])
                # print(m['path'])
    ''' (warning) check for existence of weight paths'''
    path_counts = Counter([os.path.abspath(x.get('path', '/')) for x in models])
    for url in path_counts:
        if not os.path.exists(url):
            warnings.append(f'the weight file <white>{url}</white> does not exist.')

    ''' (warning) check for non-standard keys in models '''
    for m in models:
        non_standard_keys = [x for x in m.keys() if x not in all_keys]
        if len(non_standard_keys) > 0:
            warnings.append(f'model <blue>{model_id(m)}</blue> has non standard keys: '
                            f'<green>{"</green>, <green>".join([x for x in non_standard_keys])}</green>')

    return errors, warnings


def update_metadata() -> bool:
    """ update version , machine id, install date, etc."""

    def execute(cmd: str) -> str | None:
        try:
            return subprocess.run(cmd, shell=True, capture_output=True, check=True, encoding='utf-8') \
                .stdout \
                .strip()
        except subprocess.SubprocessError:
            return None

    def read_file(fn: str) -> str | None:
        try:
            with open(fn, 'r') as f:
                return f.read()
        except FileNotFoundError:
            return None

    flag_save: bool = False

    ''' get version from .version file '''
    fn_ver = os.path.join(os.path.dirname(__file__), '../.version')
    if not os.path.exists(fn_ver):
        fn_ver = os.path.join(os.path.dirname(__file__), '.version')
    __version__ = read_file(fn_ver).strip(' \n') or '0.0.0.0'
    ''' get machine id from .id file '''
    fn_id = os.path.join(os.path.dirname(__file__), '../.id')
    if not os.path.exists(fn_id):
        fn_id = os.path.join(os.path.dirname(__file__), '.id')
    if os.path.exists(fn_id):
        with open(fn_id, 'r') as f:
            cid = f.read().strip()
    else:
        ''' get machine unique-ish id and save to .id file'''
        try:
            match sys.platform:
                case 'win32' | 'cygwin' | 'msys':
                    cid = execute("powershell.exe -ExecutionPolicy bypass -command " +
                                  "(Get-CimInstance -Class Win32_ComputerSystemProduct).UUID")
                case 'darwin':
                    cid = execute("ioreg -d2 -c IOPlatformExpertDevice | awk -F\\\" '/IOPlatformUUID/{print $(NF-1)}'")
                case 'posix' | 'linux':
                    cid = read_file('/etc/machine-id')
                    if not cid:
                        cid = read_file('/sys/class/dmi/id/product_uuid')
                case _:
                    cid = str(uuid.getnode())
        except Exception as ex:  # noqa
            cid = uuid.getnode()
        with open(fn_id, 'w') as f:
            f.write(cid)

    ''' compare to machine id in config file'''
    try:
        cur = configuration['meta']['engine_id'].split(':')[0]
        if cur != cid:
            flag_save = True
            cur = configuration['meta']['engine_id']
            if len(cur) > 10 and cur not in configuration['meta']['id_hist']:
                ''' save old machine id to history '''
                configuration['meta']['id_hist'].insert(0, cur)
            ''' update config file with new machine id '''
            configuration['meta']['engine_id'] = f'{cid}:0001'
            configuration['meta']['installed'] = datetime.date.strftime(datetime.date.today(), '%Y-%m-%d')
    except Exception as ex:  # noqa
        ''' update config file with new machine id '''
        flag_save = True
        configuration['meta']['engine_id'] = f'{cid}:0001'
        configuration['meta']['installed'] = datetime.date.strftime(datetime.date.today(), '%Y-%m-%d')
    if __version__ != configuration['meta']['version']:
        flag_save = True
        configuration['meta']['version'] = __version__
    if flag_save:
        try:
            with open(filename, 'w') as fp:
                dump(configuration, fp)
            logger.info("Updated meta part of config.toml file")
        except Exception as ex:  # noqa
            logger.error(f"Failed to update meta part of config.toml file: {ex}")
    return flag_save


if __name__ == '__main__':
    if load():
        import pprint

        logger.info('loaded configuration')
        pprint.pp(configuration)

        print('no_cc0    =', no_cc0())
        print('installed =', install_date())
        print('version   =', app_version())

# ---------------------------------------   DEFAULT CONFIG -----------------------------
__minimal_default_config = """

# -----------------------  som lpr config file --------------------------


[basic]

clip_directory = 'C:/tmp/clips'    # root directory for files uploaded to somplr engine

[[model]]
    type = 'PLATO'
    path = 'plato/weights/PLATO6K_yolox_t.xml'
    default = 1
    speed = 2
    name = 'P0_tiny'
    countries = []
    tags = [ 'single' ]
    active = 1


[[model]]
    type = 'PLATO'
    path = 'plato/weights/PLATO6K_yolox_s.xml'
    speed = 3
    name = 'P0_small'
    default = 0
    countries = [ 'single' ]
    tags = []
    active = 1


[[model]]
    type = 'SIMBA'
    path = 'simba/weights/SL1_simba_n.xml'
    default = 1
    speed = 1
    name = 'S0_nano'
    countries = []
    tags = [ 'nano' ]
    active = 1

[[model]]
    type = 'SIMBA'
    path = 'simba/weights/SL1_simba_t.xml'
    name = 'S0_tiny'
    speed = 2
    default = 0
    countries = []
    tags = [ 'tiny' ]
    active = 1

[[model]]
    type = 'SIMBA'
    path = 'simba/weights/SL1_simba_s.xml'
    name = 'S0_small'
    default =0
    speed = 3
    countries = []
    tags = [ 'small', 'slow' ]
    active = 1

[[model]]
    type = 'JOHNY'
    path = 'johny/weights/SR1-9939_dynamic.xml'
    name = 'J0_1'
    default = 1
    speed = 2
    countries = []
    tags = []
    active = 1

[[model]]
    type = 'ENDEIS'
    path = 'endeis/weights/SE1-9670.xml'
    name = 'E0_1'
    default = 1
    speed = 2
    countries = []
    tags = []
    active = 1

[[model]]
    type = 'MEILI'
    path = 'meili/weights/EXT2_yolox_t_b4.xml'
    name = 'M0_1'
    default = 1
    speed = 2
    countries = []
    tags = []
    active = 1

# ----------------------------------  end ------------------------------------- 
"""
