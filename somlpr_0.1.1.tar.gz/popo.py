# -*- coding:utf-8 -*-


__author__ = "Jakub Marczewski "
__copyright__ = "Copyright 2024, Jakub Marczewski"

"""
    Objects that encapsulates grpc objects from the AiEngine detections 
"""

import asyncio
import math
import time
import uuid
from typing import Self, Any
from dataclasses import dataclass, field
import cv2
import numpy as np
import classes
from som import AiEngineType, InferParameters, InferType, InferFlags, SomError, ClientId, Duration
import somlpr_pb2 as pb2
from google.protobuf.json_format import MessageToJson


@dataclass
class FoundObject:
    engine: AiEngineType
    name: str
    class_no: int
    rect: tuple[int, int, int, int] | list[int] = field(default_factory=lambda: [])
    confidence: float = 0.0
    parent: Any | None = None
    __area: int = -1
    __center: tuple[int, int] | None = None

    # def copy(self):
    #     return FoundObject(engine=self.engine, name=self.name, class_no=self.class_no,
    #                        rect=self.rect.copy(),
    #                        confidence=self.confidence, parent=self.parent)

    def area(self):
        try:
            if self.__area == -1:
                self.__area = int((self.rect[2] - self.rect[0]) * (self.rect[3] - self.rect[1]))
            return self.__area
        except (ZeroDivisionError, ValueError):
            return 0

    def width(self):
        return int(self.rect[2] - self.rect[0])

    def height(self):
        return int(self.rect[3] - self.rect[1])

    def tl(self):
        return self.rect[0], self.rect[1]

    def br(self):
        return self.rect[2], self.rect[3]

    def tr(self):
        return self.rect[2], self.rect[1]

    def bl(self):
        return self.rect[0], self.rect[3]

    def center(self):
        if self.__center is None:
            self.__center = (int(self.rect[0] + (self.rect[2] - self.rect[0]) / 2),
                             int(self.rect[1] + (self.rect[3] - self.rect[1]) / 2))
        return self.__center

    def to_yolox_row(self):
        """ to array [ x1,y1,x2,y2,confidence, class"""
        return [self.rect[0], self.rect[1], self.rect[2], self.rect[3], self.confidence, self.class_no]

    def ratio(self) -> float:
        try:
            self.rect[2] / self.rect[3]
        except ZeroDivisionError:
            return 1.0

    def __repr__(self):
        return (f'{self.name} ({self.center()[0]}, {self.center()[1]}), '
                f'{self.rect[2] - self.rect[0]}x{self.rect[3] - self.rect[1]},  {self.area()}')


@dataclass
class FoundVehicle(FoundObject):
    lamps: list[FoundObject] = field(default_factory=lambda: [])
    color: tuple[str, tuple[int, int, int] | str] = ('N/A', None)

    def grpc(self) -> pb2.Vehicle:
        return Serialization.grpc_vehicle(self)


@dataclass
class FoundSimba(FoundObject):
    """ Symbol found by simba brain"""
    top3: list = field(default_factory=lambda: [])
    im: np.ndarray | None = field(default=None, repr=False)

    def grpc(self) -> list[pb2.Symbol]:
        return Serialization.grpc_symbol(self)


@dataclass
class FoundMeili(FoundObject):
    """ Artefact/plate field found by meili brain"""
    top3: list = field(default_factory=lambda: [])
    im: np.ndarray | None = field(default=None, repr=False)
    plate_idx: int = -1


@dataclass
class SimbaItems:
    symbols: list[FoundSimba] = field(default_factory=lambda: [])

    @classmethod
    def parse(cls, predictions: list[np.ndarray], imgs: list[np.ndarray]) -> list[Self]:
        result = []
        for i, inference in enumerate(predictions):
            result.append(cls.parse_single(inference, imgs[i]))
        return result

    @classmethod
    def parse_single(cls, inference: np.ndarray, im: np.ndarray) -> Self:
        result = SimbaItems()
        ''' cast inference result to list of SimbaObject items ( there is only one class in Simba )'''
        detections = [
            FoundSimba(
                engine=AiEngineType.SIMBA,
                name=classes.SIMBA[int(x[5])],
                class_no=int(x[5]),
                rect=[int(x[0]), int(x[1]), int(x[2] * 1.05), int(x[3] * 1.05)],
                confidence=round(float(x[4]), 2)
            ) for x in inference]

        detections.sort(key=lambda x: x.rect[0])
        # TODO sort 2 liners

        for x in detections:
            x.im = Util.cut_x1y1x2y2_rect(im, x.rect)
        result.symbols = detections
        return result

    def symbol_images(self) -> list[np.ndarray]:
        return [x.im for x in self.symbols]

    def append_johny_inference(self, inference: dict):
        """ assign top3 classifications to each symbol """
        for i, top3 in enumerate(inference):
            self.symbols[i].top3 = top3

    def grpc(self) -> list[pb2.Symbol]:
        return Serialization.grpc_symbol(self)


@dataclass
class MeiliItems:
    artefacts: list[FoundMeili] = field(default_factory=lambda: [])

    @classmethod
    def parse(cls, inference: np.ndarray, imgs: list[np.ndarray]) -> Self:
        result = MeiliItems()
        ''' cast inference result to list of MeiliObject items '''
        detections = [
            FoundMeili(
                engine=AiEngineType.MEILI,
                name=classes.MEILI[int(x[5])],
                class_no=int(x[5]),
                rect=[int(x[0]), int(x[1]), int(x[2] * 1.05), int(x[3] * 1.05)],
                confidence=round(float(x[4]), 2),
                plate_idx=int(x[6])
            ) for x in inference]
        for x in detections:
            x.im = Util.cut_x1y1x2y2_rect(imgs[x.plate_idx], x.rect)
        result.artefacts = detections
        return result

    def get_images(self):
        return [x.im for x in self.artefacts]

    def append_endeis_inference(self, inference: list):
        """ assign top3 classifications to each symbol """
        for i, top3 in enumerate(inference):
            self.artefacts[i].top3 = top3

    def grpc(self) -> list[pb2.Artefact]:
        return Serialization.grpc_artefact(self)


@dataclass
class FoundPlate(FoundObject):
    vehicle: FoundVehicle | None = None
    lamps: list[FoundObject] = field(default_factory=lambda: [])
    im: np.ndarray | None = field(default=None, repr=False)
    symbols: SimbaItems | None = None
    artefacts: MeiliItems | None = None
    evaluated: dict = field(default_factory=dict)
    forecolor: tuple[str, tuple[int, int, int]] = ('N/A', None)
    backcolor: tuple[str, tuple[int, int, int]] = ('N/A', None)

    def post_cast(self):
        if self.vehicle and isinstance(self.vehicle, FoundObject):
            self.vehicle = FoundVehicle(self.vehicle)

    def debug_copy(self):
        c = FoundPlate(engine=self.engine, name=self.name, class_no=self.class_no)
        c.im = self.im.copy()
        c.rect = self.rect.copy()
        c.confidence = self.confidence
        c.forecolor = self.forecolor
        c.backcolor = self.backcolor
        return c

    def get_plate(self) -> str | None:
        if self.symbols is None or len(self.symbols.symbols) == 0:
            return None
        if self.symbols.symbols[0].top3 is None:
            return None
        plate = ''
        for s in self.symbols.symbols:
            plate += s.top3[0][0]
        return plate

    def get_region(self) -> str | None:
        if self.artefacts is None or len(self.symbols.symbols) == 0:
            return None
        if self.artefacts.artefacts[0].top3 is None:
            return None
        region = 'N/A'
        return region

    def eval(self) -> None:
        """ Gather all the info available and rebuild evaluated dict with best guess for plate"""
        self.evaluated = {'plate': self.get_plate()}

    def grpc(self) -> pb2.Plate:
        return Serialization.grpc_plate(self)


@dataclass
class PlatoItems:
    plates: list[FoundPlate] = field(default_factory=lambda: [])
    rogue_vehicles: list[FoundVehicle] = field(default_factory=lambda: [])
    ignored_plates: list[FoundObject] = field(default_factory=lambda: [])
    warnings: list[tuple[str, list]] = field(default_factory=lambda: [])
    im: np.ndarray | None = None
    ratio: float = -1.0
    duration: Duration | None = None
    error: Exception | None = None

    def plate_images(self):
        return [x.im for x in self.plates]

    def str_summary(self) -> str:
        s = f'{len(self.plates)} plates '
        if len(self.rogue_vehicles) > 0:
            s += f'{len(self.rogue_vehicles)} rouge '
        if len(self.ignored_plates) > 0:
            s += f'{len(self.ignored_plates)} ignored '
        return s

    def str_plates(self) -> str:
        s = ''
        if len(self.plates) <= 3:
            s += ' '.join([x.get_plate() or 'N/A' for x in self.plates])
        elif len(self.plates) > 3:
            s += f'{len(self.plates)} plates '
        if len(self.rogue_vehicles) > 0:
            s += f'{len(self.rogue_vehicles)} rouge'
        if len(self.ignored_plates) > 0:
            s += f'{len(self.ignored_plates)} ignored'
        return s

    def eval(self) -> None:
        for plate in self.plates:
            plate.eval()

    def symbol_images(self):
        imgs = []
        for p in self.plates:
            imgs.extend(p.symbols.symbol_images())
        return imgs

    def append_artefact_info(self, predictions: MeiliItems):
        for i in range(len(self.plates)):
            self.plates[i].artefacts = MeiliItems(artefacts=[p for p in predictions.artefacts if p.plate_idx == i])

    def append_symbol_info(self, predictions: list[SimbaItems]):
        for i, symbol_info in enumerate(predictions):
            self.plates[i].symbols = symbol_info

    def append_symbol_classifier(self, predictions: list):
        idx = 0
        for plate in self.plates:
            for symbol in plate.symbols.symbols:
                symbol.top3 = predictions[idx]
                idx += 1

    def limit_to_single_plate(self):
        """ Keep only the plate with the largest area and move rest to ignored_plates"""
        self.ignored_plates.extend(self.plates[1:])
        self.plates = self.plates[0:1]

    @classmethod
    def from_im(cls, im: np.ndarray) -> Self:
        result = PlatoItems()
        result.im = im
        result.ratio = min(416 / im.shape[0], 416 / im.shape[1])
        return result

    @classmethod
    def parse(cls, inference: np.ndarray, im: np.ndarray) -> Self:
        result = PlatoItems()
        result.im = im
        result.ratio = min(416 / im.shape[0], 416 / im.shape[1])
        ''' cast inference result to list of FoundObject items '''
        detections = [
            FoundObject(
                parent=result,
                engine=AiEngineType.PLATO,
                name=classes.PLATO[int(x[5])],
                class_no=int(x[5]),
                # rect=[int(x[0] * 1 / ratio), int(x[1] * 1 / ratio),
                #       int(x[2] * 1.01 * 1 / ratio), int(x[3] * 1.01 * 1 / ratio)],
                rect=[int(x[0]), int(x[1]), int(x[2] * 1.01), int(x[3] * 1.01)],
                confidence=round(float(x[4]), 2)
            ) for x in inference]

        ''' separate FoundObjects into lists by detection class '''
        plates = [x for x in detections if x.class_no == 0]
        fronts = [x for x in detections if x.class_no == 1]
        lamps = [x for x in detections if x.class_no == 2]
        backs = [x for x in detections if x.class_no == 3]
        motors = [x for x in detections if x.class_no == 4]
        ''' cast plate FoundObject items to FoundPlate items '''
        plates = [FoundPlate(**vars(x)) for x in plates]
        for plate in plates:
            plate.im = Util.cut_x1y1x2y2_rect(im, plate.rect)
        '''  pair plates with vehicles (front,back, motor) and lamps near the plate '''
        for plate in plates:
            plate_vehs = [x for x in fronts + backs + motors if intersect(x.rect, plate.rect) > 0]
            if len(plate_vehs) > 1:
                result.warnings.append((f'Found more than one vehicle connected to plate !', plate_vehs))
                # TODO sort by the one that has maximum intersecting areaa
            if len(plate_vehs) > 0:
                plate.vehicle = FoundVehicle(**plate_vehs[0].__dict__)
            for item in plate_vehs:
                try:
                    fronts.remove(item)
                except ValueError:
                    try:
                        backs.remove(item)
                    except ValueError:
                        try:
                            motors.remove(item)
                        except ValueError:
                            pass
            '''  assign lamps to plate vehicle ( via lamp intersection with vehicle )'''
            if plate.vehicle is not None:
                intersecting = [x for x in lamps if intersect(plate.vehicle.rect, x.rect)]
                plate.lamps = intersecting
                for item in intersecting:
                    lamps.remove(item)
            else:
                '''  assign lamps to plate ( via lamp distance from plate )'''
                max_lamp_dist = (plate.height() + plate.width()) * 1.5
                closeby = [x for x in lamps if distance(plate.center(), x.center()) <= max_lamp_dist]
                plate.lamps = closeby
                for item in closeby:
                    lamps.remove(item)

            result.plates.append(plate)
        ''' convert remaining front, back & motor FoundObjects into FoundRoughObjects'''
        rouge_vehs = [FoundVehicle(**vars(x)) for x in fronts + backs + motors]
        ''' pair remaining 'plate-less' fronts/backs and motors with remaining unassigned lamps '''
        for veh in rouge_vehs:
            intersecting = [x for x in lamps if intersect(veh.rect, x.rect)]
            veh.lamps = intersecting
            for l in intersecting:
                lamps.remove(l)

        result.rogue_vehicles = rouge_vehs
        if len(lamps) > 0:
            result.warnings.append((f'dropped {len(lamps)} rouge lamps', lamps))
        try:
            ''' sort plates and rouge vehicles by size ( largest area first ) '''
            result.plates.sort(key=lambda x: x.area(), reverse=True)
            result.rogue_vehicles.sort(key=lambda x: x.area(), reverse=True)

            # result.plates.sort(key=lambda x: x.area, reverse=True)
            # result.rogue_vehicles.sort(key=lambda x: x.area(), reverse=True)
            return result
        except (TypeError, ValueError):
            raise

    def __repr__(self):
        s = ''
        s = f'{len(self.plates)} x plates'
        if len(self.rogue_vehicles) > 0:
            s += f', {len(self.rogue_vehicles)} rouge vehicles'
        if len(self.warnings) > 0:
            s += f', {len(self.warnings)} warnings'
        headers = len(self.rogue_vehicles) > 0 or len(self.warnings) > 0
        if headers:
            s += '\nPlates:'
        for p in self.plates:
            s += f'   {p}'
        if headers:
            s += '\nRogue vehicles:'
        for v in self.rogue_vehicles:
            s += f'   {v}'
        if headers:
            s += '\nWarnings:'
        for w in self.warnings:
            s += f'   {w}'
        return s

    def to_yolox_infer(self):
        r = []
        for p in self.plates:
            r.append(p.to_yolox_row())
            if p.vehicle:
                r.append(p.vehicle.to_yolox_row())
            for l in p.lamps:
                r.append(l.to_yolox_row())
        for v in self.rogue_vehicles:
            r.append(v.to_yolox_row())
            for l in v.lamps:
                r.append(l.to_yolox_row())
        np_arr = np.asarray(r)
        return np_arr


class DebugMsg:

    def __init__(self, msg: str, im: np.ndarray | None):
        self.message = msg
        self.im = im


''' ______________________________________________________________________________________________  '''


def intersect(l: list[int], r: list[int]):
    dx = min(l[2], r[2]) - max(l[0], r[0])
    dy = min(l[3], r[3]) - max(l[1], r[1])
    if (dx >= 0) and (dy >= 0):
        return dx * dy
    else:
        return 0


def distance(a: tuple[int, int], b: tuple[int, int]):
    dx = abs(b[0] - a[0])
    dy = abs(b[1] - a[1])
    dist = int(math.sqrt(dx ** 2 + dy ** 2))
    return dist


class FrameQuery:

    def __init__(self, im_scene: np.ndarray):
        self.id: uuid.uuid4 = uuid.uuid4()
        self.im_scene = im_scene

    def __repr__(self):
        return f'scan {self.id[-5:]} of shape {self.im_scene.shape}'


class Util:

    @classmethod
    def cut_x1y1x2y2_rect(cls, im: np.ndarray, rect: list[int]) -> np.ndarray:
        """ cur top-left, bottom right defined rect from image"""
        return im[rect[1]:rect[3], rect[0]:rect[2]]


class SnapCommand:

    def __init__(self, context: Any | None = None):
        self.received = time.perf_counter()
        self.category: InferType = InferType.SNAPSHOT
        self.msg_id: int = 0
        self.source_id: str | None = None
        self.client_id: ClientId | None = None
        self.im: list[np.ndarray] | None = None
        self.format: str | None = None
        self.parameters: InferParameters | None = None
        self.no_copyright: int = 0
        self.verify: str | None = None  # plate number from other source for comparison
        self.verify_engine: str | None = None  # lpr source ie. Hik, Dahua, AdaptiveRecognition, PlateFinder, etc.
        self.callback_url: str | None = None  # FastApi only
        self.finished_event = asyncio.Event()
        self.scan_result: PlatoItems | SomError | None = None
        self.finished_event = asyncio.Event()
        self.error: Exception | None = None
        self.uuid: uuid.uuid4 | None = None
        self.waiver: str | None = None
        self.grpc_context = context


class ClipCommand:
    pass


class CameraCommand:

    def __init__(self):
        self.received = time.perf_counter()
        self.category: InferType = InferType.CAMERA
        self.cam_id: str | None = None
        self.url: str | None = None
        self.parameters: InferParameters | None = None
        self.callback_url: str | None = None
        self.credentials: tuple[str, str] | None = None


class TrackerSceneCommand:
    """Async Queue item for a single stream frame Plato detection"""

    def __init__(self, im: np.ndarray, parameters: InferParameters = None, queue: asyncio.Queue = None) -> None:
        self.received = time.perf_counter()
        self.im = im
        self.detections: PlatoItems | None = None
        self.parameters = parameters
        self.finished_event = asyncio.Event()
        # self.result_queue: asyncio.Queue | None = queue


class TrackerVehicleCommand:
    """ Async Queue item for a single vehicle/plate Simba(+Meli) scan. Optionally multi im and detections for
        synced front/back cameras"""

    def __init__(self, track_id: int, im: np.ndarray | list[np.ndarray],
                 detections: PlatoItems | list[PlatoItems], parameters: InferParameters = None,
                 queue: asyncio.Queue = None) -> None:
        self.received = time.perf_counter()
        self.im = im
        self.track_id = track_id  # tracker identifier for the object
        self.detections = detections
        self.parameters = parameters
        self.finished_event = asyncio.Event()
        self.result_queue: asyncio.Queue | None = queue


class Serialization:

    @classmethod
    def json(cls, pb2obj: Any) -> str:
        r = MessageToJson(pb2obj)
        return r

    @classmethod
    def grpc_debug(cls, obj: DebugMsg | list[DebugMsg]) -> list[pb2.Debug]:
        if isinstance(obj, DebugMsg):
            arr = [obj]
        else:
            arr = obj
        result = []
        for d in arr:
            r = pb2.Debug()
            r.text = d.message or ''
            if d.im is not None:
                r.png = d.im
            result.append(r)
        return result

    @classmethod
    def grpc_errorcode(self, code: int, msg: str | None = None) -> pb2.ErrorCode:
        r = pb2.ErrorCode()
        r.result = code
        r.message = msg or ''

    @classmethod
    def grpc_color(cls, value: tuple[str, str]) -> pb2.Color:
        c = pb2.Color()
        c.name = value[0] or ''
        c.hex = '#{:02x}{:02x}{:02x}'.format(*value[1]) if value[1] is not None else ''
        return c

    @classmethod
    def grpc_color_assign(cls, pb2obj: pb2.Color, value: tuple[str, tuple[int, int, int]]) -> None:
        pb2obj.name = value[0] or ''
        pb2obj.hex = value[1] or '#{:02x}{:02x}{:02x}'.format(*value[1]) if value[1] is not None else ''

    @classmethod
    def grpc_rect(cls, rect) -> list[pb2.Point]:
        tl = pb2.Point()
        tl.x = rect[0]
        tl.y = rect[1]
        br = pb2.Point()
        br.x = rect[2]
        br.y = rect[3]
        return [tl, br]

    @classmethod
    def grpc_polygon(cls, poly: list[list[int]]) -> list[pb2.Point]:
        result = pb2.Polygon()
        for point in poly:
            p = pb2.Point()
            p.x = point[0]
            p.y = point[1]
            result.points.append(p)
        return result

    @classmethod
    def grpc_parameter(cls, obj: InferParameters) -> pb2.Parameters:
        r = pb2.Parameters()
        r.speed = obj.speed
        r.flags = int(obj.flags)
        r.plato_speed = obj.plato_speed
        r.simba_speed = obj.simba_speed
        r.johny_speed = obj.johny_speed
        r.meili_speed = obj.meili_speed
        r.endeis_speed = obj.endeis_speed
        if obj.plato_name:
            r.plato_name = obj.plato_name
        if obj.simba_name:
            r.simba_name = obj.simba_name
        if obj.johny_name:
            r.johny_name = obj.johny_name
        if obj.meili_name:
            r.meili_name = obj.meili_name
        if obj.endeis_name:
            r.endeis_name = obj.endeis_name
        r.debug = obj.debug
        for poly in obj.included:
            r.included.extend(cls.grpc_poly(poly))
        return r

    @classmethod
    def grpc_parameter_assign(cls, obj: pb2.Parameters, value: InferParameters) -> None:
        obj.speed = value.speed
        obj.flags = int(value.flags)
        obj.plato_speed = value.plato_speed
        obj.simba_speed = value.simba_speed
        obj.johny_speed = value.johny_speed
        obj.meili_speed = value.meili_speed
        obj.endeis_speed = value.endeis_speed
        if value.plato_name:
            obj.plato_name = value.plato_name
        if value.simba_name:
            obj.simba_name = value.simba_name
        if value.johny_name:
            obj.johny_name = value.johny_name
        if value.meili_name:
            obj.meili_name = value.meili_name
        if value.endeis_name:
            obj.endeis_name = value.endeis_name
        obj.debug = value.debug
        obj.included.clear()
        for poly in value.included:
            obj.included.extend(cls.grpc_poly(poly))

    @classmethod
    def grpc_poly(cls, points: list[list[int]]) -> list[pb2.Point]:
        result = []
        for point in points:
            p = pb2.Point()
            p.x = point[0]
            p.y = point[1]
            result.append(p)
        return result

    @classmethod
    def grpc_vehicle(cls, obj: FoundVehicle) -> pb2.Vehicle:
        r = pb2.Vehicle()
        r.rect.extend(cls.grpc_rect(obj.rect))
        r.classified = obj.name or ''
        r.confidence = obj.confidence
        cls.grpc_color_assign(r.color, obj.color)
        return r

    @classmethod
    def grpc_vehicle_assign(cls, pb2obj: pb2.Vehicle, value: FoundVehicle) -> None:
        pb2obj.rect.extend(cls.grpc_rect(value.rect))
        pb2obj.classified = value.name or ''
        pb2obj.confidence = value.confidence
        cls.grpc_color_assign(pb2obj.color, value.color)

    @classmethod
    def grpc_symbol(cls, obj: FoundSimba | list[FoundSimba] | SimbaItems) -> list[pb2.Symbol]:
        result = []
        if isinstance(obj, SimbaItems):
            symbols = obj.symbols
        elif isinstance(obj, FoundSimba):
            symbols = [obj]
        else:
            symbols = obj
        for s in symbols:
            r = pb2.Symbol()
            r.rect.extend(Serialization.grpc_rect(s.rect))
            if s.top3:
                r.top1_char = s.top3[0][0] or ''
                r.top1_conf = s.top3[0][1] or 0.0
                r.top2_char = s.top3[1][0] or ''
                r.top2_conf = s.top3[1][1] or 0.0
                r.top3_char = s.top3[2][0] or ''
                r.top3_conf = s.top3[2][1] or 0.0
            result.append(r)
        return result

    @classmethod
    def grpc_artefact(cls, obj: MeiliItems) -> list[pb2.Artefact]:
        result = []
        for a in obj.artefacts:
            r = pb2.Artefact()
            r.rect.extend(cls.grpc_rect(a.rect))
            r.classified = a.name or ''
            r.name = f'class #{a.class_no}'
            r.top1_name = a.top3[0][0] or ''
            r.top1_conf = a.top3[0][1] or 0.0
            r.top2_name = a.top3[1][0] or ''
            r.top2_conf = a.top3[1][1] or 0.0
            r.top3_name = a.top3[2][0] or ''
            r.top3_conf = a.top3[2][1] or 0.0
            result.append(r)
        return result

    @classmethod
    def grpc_snapshot_manual(cls, im: np.ndarray, parameters: InferParameters,
                             msg_id: int | None = None, cam_id: str | None = None,
                             verify: str = None, no_copyright: bool = False) -> pb2.SnapshotRequest:
        r = pb2.SnapshotRequest()
        if msg_id:
            r.msg_id = msg_id
        if cam_id:
            r.source_id = cam_id

        # r.flags = int(parameters.flags)
        r.image = cv2.imencode('.png', im)[1].tobytes() or b''
        r.parameters = cls.grpc_parameter(parameters)
        r.no_copyright = 1 if no_copyright else 0
        if verify:
            r.verify = verify
        return r

    @classmethod
    def grpc_camera_request(cls, cam_id: str, uri: str, parameters: InferParameters) -> pb2.CameraRequest:
        r = pb2.CameraRequest()
        r.cam_id = cam_id or ''
        r.uri = uri or ''
        r.parameters = cls.grpc_parameter(parameters)
        return r

    @classmethod
    def grpc_ignored(cls, obj: FoundObject) -> pb2.Ignored:
        r = pb2.Ignored()
        r.rect = cls.grpc_rect(obj.rect)
        return r

    @classmethod
    def grpc_plate(cls, obj: FoundPlate) -> pb2.Plate:
        r = pb2.Plate()
        r.plate = obj.get_plate() or ''
        r.region = obj.get_region() or ''
        r.rect.extend(cls.grpc_rect(obj.rect))
        cls.grpc_color_assign(r.forecolor, obj.forecolor)
        cls.grpc_color_assign(r.backcolor, obj.backcolor)
        r.symbols.extend(cls.grpc_symbol(obj.symbols))
        if obj.vehicle:
            cls.grpc_vehicle_assign(r.vehicle, obj.vehicle)
            # r.vehicle = cls.grpc_vehicle(obj.vehicle)
        if obj.artefacts and len(obj.artefacts.artefacts) > 0:
            r.artefacts.extend(obj.artefacts.grpc())
        # r.comments.extend()
        # r.polygon
        return r

    @classmethod
    def grpc_frame(cls, obj: PlatoItems, msg_id: int | None = None, cam_id: str | None = None):
        r = pb2.Frame()
        if msg_id:
            r.msg_id = msg_id
        if cam_id:
            r.src_id = cam_id
        r.unix_stamp = int(time.time())
        for plate in obj.plates:
            r.plates.append(cls.grpc_plate(plate))
        for vehicle in obj.rogue_vehicles:
            r.no_plates.append(cls.grpc_vehicle(vehicle))
        for vehicle in obj.ignored_plates:
            r.no_plates.append(cls.grpc_vehicle(FoundVehicle(vehicle)))
        r.duration_ms = round(obj.duration.total_chains() * 1000)
        r.debugging.append(pb2.Debug(text=f'{obj.duration}'))
        r.error.message = 'OK'
        r.error.result = SomError.ErrorCodes.OK.value
        return r

    @classmethod
    def grpc_frame_error(cls, error: Exception | SomError,
                         cmd: SnapCommand | CameraCommand | None) -> pb2.Frame:
        r = pb2.Frame()
        if cmd:
            r.msg_id = cmd.msg_id
        if cmd and cmd.cam_id:
            r.src_id = cmd.cam_id
        r.unix_stamp = int(time.time())
        if isinstance(error, SomError):
            r.error.result = error.code.value
            r.error.message = f'[{error.code}] {error.message}'
        else:
            r.error.result = SomError.ErrorCodes.ENGINE_INTERNAL_ERROR.value
            r.error.message = f'[SomError.ErrorCodes.ENGINE_INTERNAL_ERROR:2] {error}'
        if cmd:
            r.duration_ms = round(time.perf_counter() - cmd.received * 1000)
        return r

    @classmethod
    def popo_parameters(cls, obj: pb2.Parameters) -> InferParameters:  # noqa (pb2)
        r = InferParameters()
        r.speed = obj.speed
        r.flags = [InferFlags.name for x in InferFlags if obj.flags & x.value]

        r.plato_speed = obj.plato_speed
        r.simba_speed = obj.simba_speed
        r.johny_speed = obj.johny_speed
        r.meili_speed = obj.meili_speed
        r.endeis_speed = obj.endeis_speed

        r.plato_name = obj.plato_name if len(obj.plato_name) > 0 else None
        r.simba_name = obj.simba_name if len(obj.simba_name) > 0 else None
        r.johny_name = obj.johny_name if len(obj.johny_name) > 0 else None
        r.meili_name = obj.meili_name if len(obj.meili_name) > 0 else None
        r.endeis_name = obj.endeis_name if len(obj.endeis_name) > 0 else None
        r.debug = obj.debug
        r.regions = obj.regions if len(obj.regions) > 0 else None
        for polygon in obj.included:
            poly = [(p.x, p.y) for p in polygon.points]
            r.included.append(poly)
        return r

    # @classmethod
    # def popo_polygon(cls, obj: pb2.Polygon) -> ClientId:
    #      if len(obj.api_key) == 0:
    #          return None
    #      r = ClientId()
    #      r.api_key = obj.api_key
    #      return r

    # @classmethod
    # def popo_client_id(cls, obj: pb2.ClientId) -> ClientId:
    #     if len(obj.api_key) == 0:
    #         return None
    #     r = ClientId()
    #     r.api_key = obj.api_key
    #     return r

    @classmethod
    def poco_snap_command(cls, obj: pb2.SnapshotRequest, clientid: str | None = None) -> SnapCommand:
        r = SnapCommand()
        r.msg_id = obj.msg_id
        r.cam_id = obj.source_id if len(obj.source_id) > 0 else None
        r.no_copyright = obj.no_copyright
        r.verify = obj.verify
        r.verify_engine = obj.verify_engine
        if len(obj.image) == 0:
            # no image
            raise SomError('No image in SnapshotRequest', SomError.ErrorCodes.IMAGE_PROBLEM)
        if len(obj.image) == 1:
            try:
                r.im = [cv2.imdecode(np.fromstring(obj.image[0], np.uint8), cv2.IMREAD_ANYCOLOR)]
            except Exception as ex:  # noqa
                raise SomError(f'{type(ex)} : failed to decode image by '
                               f'CV2 ({len(obj.image) if obj.image else "?"} bytes in im buffer. )',
                               SomError.ErrorCodes.IMAGE_PROBLEM, ex)
        else:
            r.im = []
            for im in obj.image:
                try:
                    r.im.append(cv2.imdecode(np.fromstring(im, np.uint8), cv2.IMREAD_ANYCOLOR))
                except Exception as ex:  # noqa
                    raise SomError(f'{type(ex)} : failed to decode image by '
                                   f'CV2 ({len(im) if im else "?"} bytes in im buffer. )',
                                   SomError.ErrorCodes.IMAGE_PROBLEM, ex)

        r.parameters = cls.popo_parameters(obj.parameters)
        if len(obj.client_id.api_key) > 0:
            r.client_id = ClientId()
            r.client_id.api_key = obj.client_id.api_key if len(obj.client_id.api_key) > 0 else None
        r.verify = obj.verify if len(obj.verify) > 0 else None
        r.callback_url = obj.callback_url if len(obj.callback_url) > 0 else None
        r.grpc_context = clientid
        return r

    @classmethod
    def poco_camera_command(cls, obj: pb2.CameraRequest) -> CameraCommand:
        r = CameraCommand()
        r.cam_id = obj.cam_id
        r.name = obj.cam_name
        r.url = obj.uri
        r.parameters = cls.popo_parameters(obj.parameters)
        r.callback_url = obj.callback_url
        r.credentials = (obj.login_user, obj.login_pass)
        return r
